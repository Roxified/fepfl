<?php ob_start(); session_start(); require('db/config.php'); require('db/functions.php');  $link = 2; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>FEPFL Marraige Academy- Crafting Blissful Marriage and Building Human Moral as Successful lifestyles for the Child with the hope of the future peaceful personality. </title>
   
   <meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="Foundation for Enhancement and Promotion of Family Life">
<meta content="family, peace, marriage, home,  " name="description">
<meta name="description" content="FEPFL Marraige Academy- Crafting Blissful Marriage and Building Human Moral as Successful lifestyles for the Child with the hope of the future peaceful personality. ">
<!-- Favicon -->
<link href="img/fepfl.jpg" rel="icon">

<!-- Google Font -->
<!-- <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet"> -->

<!-- CSS Libraries -->

<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/font/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font/css2.css">
<link href="assets/lib/flaticon/font/flaticon.css" rel="stylesheet">
<link href="assets/lib/animate/animate.min.css" rel="stylesheet">
<link href="assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

<!-- Template Stylesheet -->
<script src="assets/js/sweetalert.min.js"></script>
<script src="assets/js/vanila_del_prompt.js"></script>
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/circular-std/style.css" rel="stylesheet">

<!-- <link rel="stylesheet" type="text/css" href="css/local.css"> -->
<link rel="stylesheet" type="text/css" href="assets/css/sweetalert.css">
<link rel="stylesheet" type="text/css" href="assets/css/vanila_del_prompt.css">
</head>

<body>
    <?php include('nav/nav2.php'); ?>


    <!-- Carousel Start -->
    <div class="carousel">
        <div class="container-fluid">
            <div class="owl-carousel">
                <div class="carousel-item">
                    <div class="carousel-img">
                        <img src="img/jjj/fepel academy.jpg" alt="Image">
                    </div>
                    <div class="carousel-text">
                        <h1>FEPFL Marriage Academy</h1>
                        <p>
                            Crafting Blissful Marriage and Building Human Moral as Successful lifestyles for the Child with the hope of the future peaceful personality.
                        </p>
                        <div class="carousel-btn">
                            <a class="btn btn-custom" href="#">Register Now</a>
                            <a class="btn btn-custom" href="#">Login</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="carousel-img">
                        <img src="img/jjj/family.jpg" alt="Image">
                    </div>
                    <div class="carousel-text">
                        <h1>Enroll into FEPFL Marriage Academy</h1>
                        <p>
                            The greatest place for love is the marriage, love is life and loving is being alive, learn to love and love to live long with success in marriage and career. 
                        </p>
                        <div class="carousel-btn">
                            <a class="btn btn-custom" href="#">Register Now</a>
                            <a class="btn btn-custom" href="#">Login</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="carousel-img">
                        <img src="img/jjj/community.jpg" alt="Image">
                    </div>
                    <div class="carousel-text">
                        <h1>Bringing Smiles to Families</h1>
                        <p>
                            Peaceful marriage produces healthy people while marriage crisis kills couple gradually. 

                        </p>
                        <div class="carousel-btn">
                            <a class="btn btn-custom" href="#">Register Now</a>
                            <a class="btn btn-custom" href="#">Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Carousel End -->

  

     <!-- Service Start -->
    <div class="service">
        <div class="container">
            <div class="section-header text-center">
                <p>FEPFL Academy Objectives</p>
                <h3>To build communities of peaceful people through human moral coaching in reduce crisis, crimes and violence.</h3>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="service-icon">
                            <i class="flaticon-home"></i>
                        </div>
                        <div class="service-text">
                            <h3>FEPFL School</h3>
                            <p>FEPFL Marriage Academy is a product of “Family Peace Service 247” (FAPS 247), as a “World Peace Project” through FEPFL Marriage Academy. We build the capacities of couples in managing human emotions in marriage and family.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="service-icon">
                            <i class="far fa-file-alt"></i>
                        </div>
                        <div class="service-text">
                            <h3>Application forms</h3>
                            <p>Ready to Enroll? Kindly <a class="btn btn-custom" href="#">Click Here</a> to fill out the form below to register for the next session.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="service-item">
                        <div class="service-icon">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="service-text">
                            <h3>Student Session</h3>
                            <p>New student and Old Student (returning Students)? <a class="btn btn-custom" href="#">Click Here</a> to Proceed with registration.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

      <!-- Service Start -->
    <div class="service">
        <div class="container">
            <div class="section-header text-center">
                <p>Courses Offered</p>
                <h3>FEPFL MARRIAGE ACADEMY COURSE CODE; MARRIAGE AND CAREER PEACE SERVICES (MCPS).</h3>
            </div>
            <div class="row">
                <div class="table text-center">
                    <table class="table  table-bordered table-stripped table-hover">
                        
                        <thead><tr><th colspan="3"><h5><img src="img/fepfl.jpg" alt="FEPFL Marriage Academy Logo" width="100px"><br> FEPFL MARRIAGE ACADEMY COURSE CODE; MARRIAGE AND CAREER PEACE SERVICES (MCPS)</h5></th></tr>
                        </thead>
                        <tbody>
                            
                            <tr><th>S/N</th><th>COURSE TITLE</th><th>COURSE CODE</th></tr>
                            <tr><th colspan="3">1st Level Courses</th></tr>
                            <tr><td>01.</td><td> Marriage Emotions </td><td>MCPS 102</td></tr>
                            <tr><td>02.</td><td> Marriage Sex  </td><td>MCPS 209</td></tr>
                            <tr><td>03.</td><td> Marriage Dynamics  </td><td>MCPS 202</td></tr>
                            <tr><td colspan="3">Test and promotion to next level</td></tr>

                             <tr><th colspan="3">2nd Level Courses</th></tr>
                            <tr><td>01.</td><td> Human image in Marriage </td><td>MCPS 301</td></tr>
                            <tr><td>02.</td><td> Emotional Weather in Marriage </td><td>MCPS 304</td></tr>
                            <tr><td>03.</td><td> Understanding Communication style in Marriage  </td><td>MCPS 307</td></tr>
                            <tr><td colspan="3">Test and promotion to next level</td></tr>

                             <tr><th colspan="3">3rd Level Courses</th></tr>
                            <tr><td>01.</td><td> Enemy: The Best Teacher  </td><td>MCPS 405</td></tr>
                            <tr><td>02.</td><td>Child Emotions and Personality Formation (Parenting)   </td><td>MCPS 406</td></tr>
                            <tr><td>03.</td><td>Career and Potentials, (Easy Success)  </td><td>MCPS 407</td></tr>
                            <tr><td colspan="3">Test and promotion to next level</td></tr>

                             <tr><th colspan="3">4th Level Courses  (Special course, SPC)</th></tr>
                            <tr><td>01.</td><td> Youth Potentials, Career Success and Leadership Modeling,  (SPC) </td><td>MCPS 502</td></tr>
                            <tr><td>02.</td><td> Know Why You Feel, The Way You Feel  (Special course, SPC) </td><td>MCPS 704</td></tr>
                            <tr><td>03.</td><td> Human Personality Winging  (Special course, SPC)  </td><td>MCPS 800</td></tr>
                            <tr><td>04.</td><td> <b>CHILD BASIC RIGHT:</b> Exclusive Breast-Feeding, Child Immunization, Child Identity, Child Moral Education, Child School Enrolment, Child’s Responsibility And Parent Supervisory Etc. </td><td>SDG – UN (Child)
</td></tr>
                            <tr><td colspan="3">Test and promotion to next level</td></tr>

                         
                        </tbody>
                    </table>

                    <div>
                        <p>We Teach Knowledge That Generates Personal Peace And Transform It Into Marital Peace.
                  <p> <a href="https://www.familypeace247.org"> www.familypeace247.org</a>, <a href="mailto:info@familypeace247.org">info@familypeace247.org</a>, <a href="tel:+2348065659796">
          +234 8065 659 796, <a href="tel:++2349015442888">+234 9015 4428 88</a>,<a href="tel:++2348061316231"> +234 8061 316231</a>

                    </div>
                </div>
               
            </div>
        </div>
    </div>

        <div class="event">
        <div class="container">
            <div class="section-header text-center">
                <p>Marriage Academy Classes</p>
                <!-- <h2>Be ready for our upcoming FEPFL events</h2> -->
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="event-item">
                        <img src="img/acad/1.jpg" alt="Image">
                        <div class="event-content">
                            <div class="event-text">
                    <p><i class="fa fa-map-marker-alt"></i> Lokoja</p>

                                <h3>Marriage Academy Classes</h3>
                                <p>
                                    <?php // echo htmlspecialchars_decode($event_desc); ?>
                                </p>
                                <!-- <a class="btn btn-custom" href="#">View Now</a> -->
                            </div>
                        </div>
                    </div>
                    </div>
                     <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="event-item">
                        <img src="img/acad/2.jpg" alt="Image">
                        <div class="event-content">
                            <div class="event-text">
                              
                                <p><i class="fa fa-map-marker-alt"></i> Lokoja</p>

                                <h3>Community Leaders in FEPFL Marraige Class</h3>
                                <p>
                                    The Community in Leaders in attendance of FEPFL Marraige Academy, as a way out to stop children enrollment in cult groups on the state
                                </p>
                                
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="event-item">
                        <img src="img/acad/3.jpg" alt="Image">
                        <div class="event-content">
                            <div class="event-text">
                              
                                <p><i class="fa fa-map-marker-alt"></i> Lokoja</p>

                                <h3>Marriage Academy Classes</h3>
                                <p>
                                    The Community men and Women in attendance of FEPFL Marraige Academy, as a way of supporting the objectives of FEPFL Marraige Academy for a better Family and society.
                                </p>
                                
                            </div>
                        </div>
                    </div>
                    </div>
                      <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="event-item">
                        <img src="img/acad/4.jpg" alt="Image">
                        <div class="event-content">
                            <div class="event-text">
                              
                                <p><i class="fa fa-map-marker-alt"></i> Lokoja</p>

                                <h3>NGO Leaders in FEPFL Marriage Academy</h3>
                                <p>
                                    The Leaders of network NGOs in Kogi State have given their support to FEPFL Marriage Academy, for the sake of children in who are often the first victim of marital crisis.
                                
                            </div>
                        </div>
                    </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="event-item">
                        <img src="img/acad/5.jpg" alt="Image">
                        <div class="event-content">
                            <div class="event-text">
                              
                                <p><i class="fa fa-map-marker-alt"></i> Lokoja</p>

                                <h3>Catholic Priest in FEPFL Marriage Academy</h3>
                                <p>
                                    The Religious Leaders also joins FEPFL Marriage Academy to support the movement of a ppeaceful marriage for a peaceful society.
                                
                            </div>
                        </div>
                    </div>
                    </div> 
                    
                </div>
            </div>
        </div>
    <!-- Event Start -->
    <div class="event">
        <div class="container">
            <div class="section-header text-center">
                <p>Upcoming Events</p>
                <h2>Be ready for our upcoming FEPFL events</h2>
            </div>
            <div class="row">
              <?php foreach(QueryDB("SELECT * FROM events where status = 0 ORDER BY RAND() LIMIT 6 ") as $rows){ extract($rows); ?>
                <div class="col-lg-6">
                    <div class="event-item">
                        <img src="master/<?php  echo $img; ?>" alt="Image">
                        <div class="event-content">
                            <div class="event-text">
                                <div class="event-meta">
                                    <p><i class="fa fa-calendar-alt"></i><?php  echo date('d', strtotime($startDate)); ?>-<?php  echo date('d M Y', strtotime($endDate)); ?> </p>
                                    <p><i class="far fa-clock"></i><?php  echo date('h:i A',strtotime($startTime)); ?> - <?php  echo date('h:i A',strtotime($endTime)); ?></p>
                                </div>
                                <p><i class="fa fa-map-marker-alt"></i> <?php  echo $location; ?></p>

                                <h3><?php  echo $event_name; ?></h3>
                                <p>
                                    <?php  echo htmlspecialchars_decode($event_desc); ?>
                                </p>
                                <a class="btn btn-custom" href="post/<?php echo $event_id; ?>/<?php echo strtolower(str_replace(' ', '-', $event_name)); ?>">View Now</a>
                            </div>
                        </div>
                    </div>
                    </div>  <?php  }  ?>
                    
                </div>
            </div>
        </div>
        <!-- Event End -->
        <?php include('team.php'); ?>

        <?php include('nav/footer.php'); include('nav/scripts.php'); ?>
    </body>
    </html>
