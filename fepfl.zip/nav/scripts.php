     <!-- JavaScript Libraries -->
     <script src="assets/js/jquery-3.4.1.min.js"></script>
     <script src="assets/js/bootstrap.bundle.min.js"></script>
     <script src="assets/lib/easing/easing.min.js"></script>
     <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
     <script src="assets/lib/waypoints/waypoints.min.js"></script>
     <script src="assets/lib/counterup/counterup.min.js"></script>
     <script src="assets/lib/parallax/parallax.min.js"></script>
     <script src="assets/js/sweetalert.min.js"></script>
     <script src="assets/js/vanila_del_prompt.js"></script>
     <script type="text/javascript" src="assets/js/countries.js"></script>
     <!-- Template Javascript -->
     <script src="assets/js/main.js"></script> 
     <script type="text/javascript" src="assets/js/parsley.js"></script>
     <script src="assets/js/xl-toast.js"></script>

     <script>

        $('#state').on('change',function () {
    //alert('Changed');
    var get_id =  $(this).find('option:selected').attr('id');
    //alert(get_id);
    get_country  = $("#country").val();
    // alert(get_id + get_country);
    if(get_country=='Nigeria'){
        $.ajax({url: 'get_state', type: 'POST',data: {stateIdLGA: get_id},success: function (result) {
            $('#lga').html(result); }  });
    }
})

        $("#country").on('change', function () {
          var getId =  $(this).find('option:selected').attr('id'); getValue = $(this).val(); 
  if(getValue=='Nigeria'){ //$('#postal').hide();
  // $('.stretch').removeClass('col-md-6');    $('.stretch').addClass('col-md-12');
  $.ajax({url: 'get_state', type: 'POST',data: {stateIdN: getId},success: function (result) {
    $('#state').html(result);
    // alert(result);
}  });

}else{
    $('#lga').remove();
    $('#lga2').remove();
    $.ajax({url: 'get_state', type: 'POST',data: {stateId: getId},success: function (result) {
        $('#state').html(result);
    // alert(result);
}

});
}


});
</script>
