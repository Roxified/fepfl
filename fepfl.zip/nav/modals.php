  <!-- Video Modal Start-->
        <div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>        
                        <!-- 16:9 aspect ratio -->
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="" id="video"  allowscriptaccess="always" allow="autoplay"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        <!-- Video Modal End -->

          <!-- form Modal Start-->
        <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            Close <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div>
                            <h2>Students Signup Form</h2>
                            <hr>
                        <p>Kindly Signup to FEPFL Academy.</p>
                            <form action="" method="POST">

                                 <?php  if(isset($_POST['reg'])){
        $uname = validate($_POST['uname']);
        $ucode = validate($_POST['ucode']);
        $email = validate($_POST['email']);
        $pass = validate($_POST['pass']);
        if(validate($_POST['cpass']) === $_POST['pass']){
            $cpass = validate($_POST['cpass']);




            
        } else {
            $message = '<div class="alert alert-danger alert-dismissible col-md-12 text-center" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span></button> <strong class="text-italic" style="color:black;">
Invalid Login Credentials.
       </div>';
        }


    }



     ?>
                                <div class="form-group">
                                    <div class="col-md-12"><?php  echo @$message;  ?></div>
                                    <label class="control-label" for="firstname">Enter a valid email</label><span class="required"> *</span>
                                    <input type="email" class="form-control" name="email" required="" placeholder="Enter a valid Email">
                                  
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="firstname">Choose a Username:</label><span class="required"> *</span>
                                    <input type="text" name="uname" required="" placeholder="e.g John" class="form-control">
                                    <input type="hidden" name="ucode" required="" value="<?php echo get_code(); ?>" class="form-control"> 
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="lastname">Choose a strong password:</label><span class="required"> *</span>
                                    <input type="text" name="pass" required="" placeholder="Choose password" class="form-control"> 
                                </div>
                                <div class="form-group ">
                                    <label class="control-label" for="othername">Confirm Password </label>
                                    <input type="text" name="cpass" placeholder="Confirm password" class="form-control"> 
                                </div>
                                <div class="form-group ">
                                    
                                    

                                <div class="form-group">
                                    <input type="submit" name="reg" value="Register" class="form-control btn btn-primary">
                                    <div class="form-group"><div class="success"></div>
                                        <h5>Already registered? <a href="login" class="btn btn-info">Login</a></h5>
                                    </div>                              
                                </div>
                              

                            </form>
                        </div>     
                        <!-- 16:9 aspect ratio -->
                      
                    </div>
                </div>
            </div>
        </div> 
        <!-- form Modal End -->


<!--Appl for  loan-->
<!-- <div id="form" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog reduceLogin"><div class="modal-content col-md-12">
<div class="modal-header " style="color:purple;font-family:cursive;text-align: center;">
   </div><div class="modal-body"><h2 class="text-center style_disp" style="color:red;"><i class="fa fa-users"></i> Add Loan Type</h2>
    <form action='manageLoans' method='POST' role='form'>
<div class="col-md-6"><label>Loan ID: </label><input type="text" name="loan_id" class="form-control input-xs" readonly="" value="" style="margin-bottom:1%;" required=""></div>
<div class="col-md-6"><label>Loan Type: </label><input type="text" name="loan_type" class="form-control input-xs" required="" placeholder="Loan Type" style="margin-bottom:1%;" required=""></div>
<div class="col-md-6"><label>Loan Rate: </label><input type="number" name="loan_rate" class="form-control input-xs" required="" placeholder="Interest Rate" style="margin-bottom:1%;" required=""></div>
<div class="col-md-6"><label>Loan Duration: </label><select name="loan_time" class="form-control input-xs"  style="margin-bottom:1%;" required=""><option value="">Choose Duration</option><option value="3">3 Months</option><option value="6">6 Months</option><option value="12">12 Months</option>
</select></div>
<input type="submit" name="add_loan" class="form-control btn btn-primary" value="Add Loan Type" style="margin-bottom:2%;">
<br>
</form></div><button class="btn btn-primary pull-right" data-dismiss="modal"  style="margin-bottom: 10px">Close</button><br></div></div></div>
 -->






<!--Forgotten Password-->
<!--  -->