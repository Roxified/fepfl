

<?php ob_start(); session_start(); require('../db/config.php'); require('../db/functions.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Email Confirmation</title>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Foundation for Enhancement and Promotion of Family Life">
    <meta content="family, peace, marriage, home,  " name="description">

    <!-- Favicon -->
    <link href="../img/jjj/logo.png" rel="icon">

    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/font/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/font/css2.css">
    <link href="../assets/lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="../assets/lib/animate/animate.min.css" rel="stylesheet">
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <script src="../assets/js/sweetalert.min.js"></script>
    <script src="../assets/js/vanila_del_prompt.js"></script>
    <link href="../assets/css/style.css" rel="stylesheet">

    <!-- <link rel="stylesheet" type="text/css" href="css/local.css"> -->
    <link rel="stylesheet" type="text/css" href="../assets/css/sweetalert.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/vanila_del_prompt.css">
    <?php //include('nav/links.php'); ?>
    <link href="../assets/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/lib/css/style.css">
</head>

<body>
    <?php include('nav.php'); ?>

    <!-- Page Header Start -->
    <div class="page-header">
        <div class="container">
            <div class="row">

            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Contact Start -->
    <div class="contact">
        <div class="container">
            <div class="section-header text-center">

                <h2>Payment Failed</h2>
                <p>Ytr again</p>
            </div>


        </div>
    </div>
    <!-- Contact End -->

    <div class="footer bg-dark">
        <div class="container">
            <div class="row">
                <div class="container copyright  text-white">
                    <div class="row">
                        <div class="col-md-6">
                            <p style="display: none">&copy; <a href="#">Your Site Name</a>, All Right Reserved.</p>
                            <p >Copyright &copy; <a href="https://www.familypeace247.org">Family Peace 247</a>, All Right Reserved <?php  echo date('Y'); ?>.</p>
                        </div>
                        <div class="col-md-6">
                            <p>Designed By <a href="https://wa.me/2349024945875" target="_blank">Brainpals Resources</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php //include('nav/scripts.php'); ?>

    <!-- JavaScript Libraries -->
    <script src="../assets/js/jquery-3.4.1.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/counterup/counterup.min.js"></script>
    <script src="../assets/lib/parallax/parallax.min.js"></script>
    <script src="../assets/js/sweetalert.min.js"></script>
    <script src="../assets/js/vanila_del_prompt.js"></script>
    <script src="../assets/js/countries.js"></script>
    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script> 
    <script src="../assets/js/parsley.js"></script>
    <script src="../assets/js/xl-toast.js"></script>
    <script>
        jQuery('<div class="quantity-nav"><div class="quantity-button quantity-up">+</div><div class="quantity-button quantity-down">-</div></div>').insertAfter('.quantity input');
        jQuery('.quantity').each(function() {
            var spinner = jQuery(this),
            input = spinner.find('input[type="number"]'),
            btnUp = spinner.find('.quantity-up'),
            btnDown = spinner.find('.quantity-down'),
            min = input.attr('min'),
            max = input.attr('max');

            btnUp.click(function() {
                var oldValue = parseFloat(input.val());
                if (oldValue >= max) {
                    var newVal = oldValue;
                } else {
                    var newVal = oldValue + 1;
                }
                spinner.find("input").val(newVal);
                spinner.find("input").trigger("change");
            });

            btnDown.click(function() {
                var oldValue = parseFloat(input.val());
                if (oldValue <= min) {
                    var newVal = oldValue;
                } else {
                    var newVal = oldValue - 1;
                }
                spinner.find("input").val(newVal);
                spinner.find("input").trigger("change");
            });
        });
    </script>
</body>
</html>
