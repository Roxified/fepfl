<?php  ob_start(); session_start(); require '../db/config.php'; require '../db/functions.php';



if(QueryDB("SELECT COUNT(*) FROM payment where pay_id ='".$_GET['reference']."'  ")->fetchColumn()>0){
  $getter = QueryDB("SELECT * FROM payment where pay_id ='".$_GET['reference']."'  ");
  $rows = $getter->fetch(PDO::FETCH_ASSOC);

  $get_user = get_user_details($rows['pay_user']);

  $book_id = $rows['pay_ref'];
  $dBuk = get_spef_book($book_id);
  echo $book_location = 'master/'.$dBuk['book_path'];

}
?>

