<!-- Top Bar Start -->
<div class="top-bar d-none d-md-block">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="top-bar-left">
                    <div class="text">
                     <a href="tel:234 806 5659 796"><i class="fa fa-phone-alt"></i>
                        <p>+234 806 5659 796</p></a>
                    </div>
                    <div class="text">
                        <i class="fa fa-envelope"></i>
                        <p>info@familypeace247.org</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="top-bar-right">
                    <div class="social">
                        <a href=""><i class="fab fa-twitter"></i></a>
                        <a href=""><i class="fab fa-facebook-f"></i></a>
                        <a href=""><i class="fab fa-linkedin-in"></i></a>
                        <a href=""><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Top Bar End -->

<!-- Nav Bar Start -->
<div class="navbar navbar-expand-lg bg-dark navbar-dark">
    <div class="container-fluid">
        <a href="index" class="navbar-brand">FEPFL</a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div class="navbar-nav ml-auto">
                <a href="../index" class="nav-item nav-link <?php if ($link==1){ echo "active"; } ?>">Home</a>
                <a href="../academy" class="nav-item nav-link <?php if ($link==2){ echo "active"; } ?>">Academy</a>
                <a href="../blog" class="nav-item nav-link <?php if($link==3){echo "active"; } ?>">Blog</a>
                <a href="../books" class="nav-item nav-link <?php if ($link==7){ echo "active"; } ?>">Publications</a>

                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle <?php if ($link==4){ echo "active"; } ?>" data-toggle="dropdown">Events</a>
                    <div class="dropdown-menu">
                        <a href="#" class="dropdown-item">Upcoming</a>
                        <a href="#" class="dropdown-item">Outreaches</a>
                        <a href="#" class="dropdown-item">Seminars</a>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle <?php if ($link==5){ echo "active"; } ?>" data-toggle="dropdown" >About FEPFL</a>
                    <div class="dropdown-menu">
                        <a href="../about" class="dropdown-item">Overview</a>
                        <a href="#" class="dropdown-item">What We Do</a>
                        <a href="#" class="dropdown-item">Meet The Team</a>
                        <a href="#" class="dropdown-item">Become A Volunteer</a>
                    </div>
                </div>
                <a href="../contact" class="nav-item nav-link <?php if ($link==6){ echo "active"; } ?>">Contact</a>
                <?php if(empty($_SESSION['usercode'])){ ?>
                    <a href="../login" class="nav-item nav-link <?php if ($link==6){ echo "active"; } ?>"><i class="fa fa-user"></i> Login</a>
                    <a href="../signup" class="nav-item nav-link <?php if ($link==6){ echo "active"; } ?>">Signup</a>
                <?php  } else{                        ?>
                    <a href="../logout" class="nav-item nav-link btn btn-danger"><i class="fa fa-cancel"></i> Logout</a> <?php }  ?>
                </div>
            </div>
        </div>
    </div>
        <!-- Nav Bar End -->