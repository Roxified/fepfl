<?php  ob_start(); session_start(); require('../db/config.php'); require('../db/functions.php');

$get_title = $_REQUEST['link'];

$_SESSION['book'] = $get_title;
if(isset($_SESSION['usercode']) & isset($_SESSION['user_email'])){ $users = extract(get_user_details($_SESSION['user_email'])); } else{}
//echo "this is the user_code: ". $_SESSION['usercode'];
$find_title = $db->query("SELECT * FROM  books WHERE book_id ='".$_SESSION['book']."'  ");
$query_row = $find_title->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Buy Books - FEPFL Publications</title>
    
    <?php include('link.php'); ?>
</head>

<body>
    <?php include('nav.php'); ?>

    <!-- Page Header Start -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Books Page</h2>
                </div>
                <div class="col-12">
                    <a href="../../../index">Home</a>
                    <a href="">Buy Books</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Single Post Start-->
    <div class="single">
        <div class="container">
           <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 pr-xl-0 pr-lg-0 pr-md-0  m-b-30">
                <div class="product-slider">
                    <div id="productslider-1" class="product-carousel carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img class="d-block" src="../../../master/<?php echo $query_row['book_img']; ?>" width="100%" alt="First slide">
                            </div>
                            <div class="carousel-item">
                                <img class="d-block" src="../../../master/<?php echo $query_row['book_img']; ?>" width="100%" alt="Second slide">
                            </div>
                            <div class="carousel-item">
                                <img class="d-block" src="../../../master/<?php echo $query_row['book_img']; ?>" width="100%" alt="Third slide">
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                           <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                           <span class="sr-only">Previous</span>
                       </a>
                       <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 pl-xl-0 pl-lg-0 pl-md-0 border-left m-b-30">
            <div class="product-details">
                <div class="border-bottom pb-3 mb-3">
                    <h2 class="mb-3"><?php echo $query_row['book_name'];//['book_name']; ?></h2>
                    <div class="product-rating d-inline-block float-right">
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                        <i class="fa fa-fw fa-star"></i>
                    </div>
                    <h3 class="mb-0 text-primary"><del>N</del> <?php echo $query_row['book_price']; ?></h3>
                </div>
                                        <!-- <div class="product-colors border-bottom">
                                            <h4>Select Colors</h4>
                                            <input type="radio" class="radio" id="radio-1" name="group" />
                                            <label for="radio-1"></label>
                                            <input type="radio" class="radio" id="radio-2" name="group" />
                                            <label for="radio-2"></label>
                                            <input type="radio" class="radio" id="radio-3" name="group" />
                                            <label for="radio-3"></label>
                                        </div> -->
                                        
                                        <div class="product-description">
                                            <h4 class="mb-1">Descriptions</h4>
                                            <p><?php echo htmlspecialchars_decode($query_row['book_desc']); ?></p>
                                            
                                            <form action="" method="POST">
                                                <?php if(isset($_POST['buy'])){
                                                    if(!isset($_SESSION['usercode'])){


                                                        echo  '<div class="alert alert-success alert-dismissible col-md-12 text-center" role="alert">
                                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span></button> <strong class="text-italic" style="color:black;">
                                                        Redirecting to Login Page -Please Wait.. <i class="fa fa-spinner fa-spin"></i>
                                                        </div>';
                                                        header("refresh:3; url=../../../login.php");         
                                                    } else{
                                                        echo  '<div class="alert alert-success alert-dismissible col-md-12 text-center" role="alert">
                                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span></button> <strong class="text-italic" style="color:black;">
                                                        Processing Payments -Please Wait.. <i class="fa fa-spinner fa-spin"></i>
                                                        </div>';
                                                        header('location:../../checkout.php');
                                                    }
                                                } ?>
                                                <div class="form-submit">
                                                    <input type="submit" class="btn btn-primary btn-block btn-lg" name="buy" value="Proceed to Payment">
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 m-b-60">
                                    <div class="simple-card">
                                        <ul class="nav nav-tabs" id="myTab5" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active border-left-0" id="product-tab-1" data-toggle="tab" href="#tab-1" role="tab" aria-controls="product-tab-1" aria-selected="true">About Author</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="product-tab-2" data-toggle="tab" href="#tab-2" role="tab" aria-controls="product-tab-2" aria-selected="false">Reviews</a>
                                            </li>
                                        </ul>
                                        <div class="tab-content" id="myTabContent5">
                                            <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="product-tab-1">
                                                <p><?php echo htmlspecialchars_decode($query_row['about_author']); ?></p>

                                            </div>
                                            <div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="product-tab-2">
                                                <div class="review-block">
                                                    <p class="review-text font-italic m-0">“Vestibulum cursus felis vel arcu convallis, viverra commodo felis bibendum. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin non auctor est, sed lacinia velit. Orci varius natoque penatibus et magnis dis parturient montes nascetur ridiculus mus.”</p>
                                                    <div class="rating-star mb-4">
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                    </div>
                                                    <span class="text-dark font-weight-bold">Virgina G. Lightfoot</span><small class="text-mute"> (Company name)</small>
                                                </div>
                                                <div class="review-block border-top mt-3 pt-3">
                                                    <p class="review-text font-italic m-0">“Integer pretium laoreet mi ultrices tincidunt. Suspendisse eget risus nec sapien malesuada ullamcorper eu ac sapien. Maecenas nulla orci, varius ac tincidunt non, ornare a sem. Aliquam sed massa volutpat, aliquet nibh sit amet, tincidunt ex. Donec interdum pharetra dignissim.”</p>
                                                    <div class="rating-star mb-4">
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                    </div>
                                                    <span class="text-dark font-weight-bold">Ruby B. Matheny</span><small class="text-mute"> (Company name)</small>
                                                </div>
                                                <div class="review-block  border-top mt-3 pt-3">
                                                    <p class="review-text font-italic m-0">“ Cras non rutrum neque. Sed lacinia ex elit, vel viverra nisl faucibus eu. Aenean faucibus neque vestibulum condimentum maximus. In id porttitor nisi. Quisque sit amet commodo arcu, cursus pharetra elit. Nam tincidunt lobortis augueat euismod ante sodales non. ”</p>
                                                    <div class="rating-star mb-4">
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                        <i class="fa fa-fw fa-star"></i>
                                                    </div>
                                                    <span class="text-dark font-weight-bold">Gloria S. Castillo</span><small class="text-mute"> (Company name)</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="comment-form">
                                <h2>Leave a Review</h2>
                                <form>
                                    <div class="form-group">
                                        <label for="name">Name *</label>
                                        <input type="text" class="form-control" id="name">
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email *</label>
                                        <input type="email" class="form-control" id="email">
                                    </div>
                                    <div class="form-group">
                                        <label for="website">Website</label>
                                        <input type="url" class="form-control" id="website">
                                    </div>

                                    <div class="form-group">
                                        <label for="message">Message *</label>
                                        <textarea id="message" cols="30" rows="5" class="form-control"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" value="Post Review" class="btn btn-custom">
                                    </div>
                                </form>
                            </div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 m-b-10">
                                        <h3> Related Books</h3>
                                    </div>
                                    <?php  foreach (get_book_details() as $rows) {extract($rows); ?>
                                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                            <div class="product-thumbnail">
                                               <div class="product-img-head">
                                                <div class="product-img">
                                                    <img src="../../../master/<?php echo $book_img; ?>" alt="" class="img-fluid"></div>
                                                    <div class="ribbons"><?php echo get_time_ago($book_date); ?></div>
                                                    
                                                </div>
                                                <div class="product-content">
                                                    <div class="product-content-head">
                                                        <h3 class="product-title"><?php echo $book_name; ?></h3>
                                                        <p>Price: <del>N</del><?php echo $book_price; ?></p>


                                                    </div>
                                                    <div class="product-btn">
                                                        <a href="../../../buy_book/<?php echo $book_id; ?>/<?php echo date('Y',$book_date); ?>/<?php echo strtolower(str_replace(' ', '-', $book_name)); ?>" class="btn btn-primary">Buy Now</a>
                                                        <a href="../../../buy_book/<?php echo $book_id; ?>/<?php echo date('Y',$book_date); ?>/<?php echo strtolower(str_replace(' ', '-', $book_name)); ?>" class="btn btn-outline-light">Details</a>
                                                        <!--   <a href="#" class="btn btn-outline-light"><i class="fas fa-exchange-alt"></i></a> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    <?php } ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single Post End-->   
                    <div class="footer bg-dark">
                        <div class="container">
                            <div class="row">
                                <div class="container copyright  text-white">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p style="display: none">&copy; <a href="#">Your Site Name</a>, All Right Reserved.</p>
                                            <p >Copyright &copy; <a href="https://www.familypeace247.org">Family Peace 247</a>, All Right Reserved <?php  echo date('Y'); ?>.</p>
                                        </div>
                                        <div class="col-md-6">
                                            <p>Designed By <a href="https://wa.me/2349024945875" target="_blank">Roxified Global Services</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php //include('nav/scripts.php'); ?>

                    <!-- JavaScript Libraries -->
                    <script src="../../../assets/js/jquery-3.4.1.min.js"></script>
                    <script src="../../../assets/js/bootstrap.bundle.min.js"></script>
                    <script src="../../../assets/lib/easing/easing.min.js"></script>
                    <script src="../../../assets/lib/owlcarousel/owl.carousel.min.js"></script>
                    <script src="../../../assets/lib/waypoints/waypoints.min.js"></script>
                    <script src="../../../assets/lib/counterup/counterup.min.js"></script>
                    <script src="../../../assets/lib/parallax/parallax.min.js"></script>
                    <script src="../../../assets/js/sweetalert.min.js"></script>
                    <script src="../../../assets/js/vanila_del_prompt.js"></script>
                    <script src="../../../assets/js/countries.js"></script>
                    <!-- Template Javascript -->
                    <script src="../../../assets/js/main.js"></script> 
                    <script src="../../../assets/js/parsley.js"></script>
                    <script src="../../../assets/js/xl-toast.js"></script>
                    <script>
                        jQuery('<div class="quantity-nav"><div class="quantity-button quantity-up">+</div><div class="quantity-button quantity-down">-</div></div>').insertAfter('.quantity input');
                        jQuery('.quantity').each(function() {
                            var spinner = jQuery(this),
                            input = spinner.find('input[type="number"]'),
                            btnUp = spinner.find('.quantity-up'),
                            btnDown = spinner.find('.quantity-down'),
                            min = input.attr('min'),
                            max = input.attr('max');

                            btnUp.click(function() {
                                var oldValue = parseFloat(input.val());
                                if (oldValue >= max) {
                                    var newVal = oldValue;
                                } else {
                                    var newVal = oldValue + 1;
                                }
                                spinner.find("input").val(newVal);
                                spinner.find("input").trigger("change");
                            });

                            btnDown.click(function() {
                                var oldValue = parseFloat(input.val());
                                if (oldValue <= min) {
                                    var newVal = oldValue;
                                } else {
                                    var newVal = oldValue - 1;
                                }
                                spinner.find("input").val(newVal);
                                spinner.find("input").trigger("change");
                            });

                        });
                    </script>

                </body>
                </html>
