<?php  ob_start(); session_start(); require('db/config.php'); require('db/functions.php');
if(isset($_SESSION['usercode']) && isset($_SESSION['user_email']) && isset($_SESSION['buy_book']) &&isset($_SESSION['title'])){ 
    $users = extract(get_user_details($_SESSION['user_email'])); 
    $book_det = extract(get_spef_book($_SESSION['buy_book'])); } else{ header('location:'.$referer); } $link = 4;  ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Books - FEPFL Publications</title>
        <?php include('nav/links.php'); ?>
        <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/libs/css/style.css">
    </head>

    <body>
        <?php include('nav/nav.php'); ?>

        <!-- Page Header Start -->
        <div class="page-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>Books Page</h2>
                    </div>
                    <div class="col-12">
                        <a href="">Home</a>
                        <a href="">Detail</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- Single Post Start-->
        <div class="single">
            <div class="container">

                <div class="row">
                    <div class=" col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 pr-xl-0 pr-lg-0 pr-md-0  m-b-30">
                                <div class="product-slider">
                                    <div id="productslider-1" class="product-carousel carousel slide" data-ride="carousel">
                                        <ol class="carousel-indicators">
                                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                                        </ol>
                                        <div class="carousel-inner">
                                            <div class="carousel-item active">
                                                <img class="d-block" src="master/<?php echo $book_img; ?>" width="100%" alt="First slide">
                                            </div>
                                            <div class="carousel-item">
                                                <img class="d-block" src="master/<?php echo $book_img; ?>" width="100%" alt="Second slide">
                                            </div>
                                            <div class="carousel-item">
                                                <img class="d-block" src="master/<?php echo $book_img; ?>" width="100%" alt="Third slide">
                                            </div>
                                        </div>
                                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                         <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                         <span class="sr-only">Previous</span>
                                     </a>
                                     <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 pl-xl-0 pl-lg-0 pl-md-0 border-left m-b-30">
                            <div class="product-details">
                                <div class="border-bottom pb-3 mb-3">
                                    <h2 class="mb-3"><?php echo $book_name;//['book_name']; ?></h2>
                                    <div class="product-rating d-inline-block float-right">
                                        <i class="fa fa-fw fa-star"></i>
                                        <i class="fa fa-fw fa-star"></i>
                                        <i class="fa fa-fw fa-star"></i>
                                        <i class="fa fa-fw fa-star"></i>
                                        <i class="fa fa-fw fa-star"></i>
                                    </div>
                                    <h3 class="mb-0 text-primary"><del>N</del> <?php echo $book_price ?></h3>
                                </div>
                                        <!-- <div class="product-colors border-bottom">
                                            <h4>Select Colors</h4>
                                            <input type="radio" class="radio" id="radio-1" name="group" />
                                            <label for="radio-1"></label>
                                            <input type="radio" class="radio" id="radio-2" name="group" />
                                            <label for="radio-2"></label>
                                            <input type="radio" class="radio" id="radio-3" name="group" />
                                            <label for="radio-3"></label>
                                        </div> -->

                                        <div class="product-description">
                                            <h4 class="mb-1">Descriptions</h4>
                                            <!-- <p>It is the human emotional qualities you dig out in your courtship, you will enjoy in your marriage. Courtship is the foundation of a peaceful marriage. Marriage starts with the marriage vows. The vow says…“in health and in sickness”… the sickness that is being referred to, is the human physical illness while the real sickness that affects the marriage is the human emotional sickness. Every human being goes rough emotionally in every twenty-four hours (24hr)” at least for few minutes. The display of maturity in marriage is the ability to manage the human emotional instabilities of the couple. Responsibility equal maturity and the consequence is peace. </p> -->

                                            <form id="paymentForm">
                                                <div class="form-group row">
                                                    <label for="inputEmail2" class="col-3 col-lg-2 col-form-label text-right">Email</label>
                                                    <div class="col-9 col-lg-10">
                                                        <input id="email-address" type="email" readonly="" value="<?php echo $email;  ?>" placeholder="Email" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label for="inputEmail2" class="col-3 col-lg-2 col-form-label text-right">Full Name</label>
                                                    <div class="col-9 col-lg-10">
                                                        <input id="" type="text" readonly="" value="<?php echo $fname; ?>" class="form-control">
                                                    </div>
                                                </div><div class="form-group row">
                                                    <label for="" class="col-3 col-lg-2 col-form-label text-right">Phone: </label>
                                                    <div class="col-9 col-lg-10">
                                                        <input id="" type="text" readonly="" value="<?php echo $phone; ?>" class="form-control">
                                                    </div>
                                                </div><div class="form-group row">
                                                    <label for="inputEmail2" class="col-3 col-lg-2 col-form-label text-right">Price</label>
                                                    <div class="col-9 col-lg-10">
                                                        <input id="amount" type="text" readonly="" value="<?php echo $book_price; ?>" class="form-control">
                                                    </div>
                                                    <div class="col-9 col-lg-10">
                                                        <input id="ref" type="hidden" readonly=""  value="<?php echo $book_id; ?>" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="form-submit">
                                                    <button type="submit" class="btn btn-primary btn-block btn-lg" onclick="payWithPaystack()">Proceed to Payment </button>
                                                </div>
                                            </form>
                                            <script src="https://js.paystack.co/v1/inline.js"></script> 
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Post End-->   
            <div class="footer bg-dark">
                <div class="container">
                    <div class="row">
                        <div class="container copyright  text-white">
                            <div class="row">
                                <div class="col-md-6">
                                    <p style="display: none">&copy; <a href="#">Your Site Name</a>, All Right Reserved.</p>
                                    <p >Copyright &copy; <a href="https://www.familypeace247.org">Family Peace 247</a>, All Right Reserved <?php  echo date('Y'); ?>.</p>
                                </div>
                                <div class="col-md-6">
                                    <p>Designed By <a href="https://wa.me/2349024945875" target="_blank">Roxified Global Services</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('nav/scripts.php'); ?>
            <?php include('initialize.php'); include('callback.php'); ?>
            <script>
                jQuery('<div class="quantity-nav"><div class="quantity-button quantity-up">+</div><div class="quantity-button quantity-down">-</div></div>').insertAfter('.quantity input');
                jQuery('.quantity').each(function() {
                    var spinner = jQuery(this),
                    input = spinner.find('input[type="number"]'),
                    btnUp = spinner.find('.quantity-up'),
                    btnDown = spinner.find('.quantity-down'),
                    min = input.attr('min'),
                    max = input.attr('max');

                    btnUp.click(function() {
                        var oldValue = parseFloat(input.val());
                        if (oldValue >= max) {
                            var newVal = oldValue;
                        } else {
                            var newVal = oldValue + 1;
                        }
                        spinner.find("input").val(newVal);
                        spinner.find("input").trigger("change");
                    });

                    btnDown.click(function() {
                        var oldValue = parseFloat(input.val());
                        if (oldValue <= min) {
                            var newVal = oldValue;
                        } else {
                            var newVal = oldValue - 1;
                        }
                        spinner.find("input").val(newVal);
                        spinner.find("input").trigger("change");
                    });

                });
            </script>

        </body>
        </html>
