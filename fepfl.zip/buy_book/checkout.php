<?php  ob_start(); session_start(); require('../db/config.php'); require('../db/functions.php');

//$get_title = $_REQUEST['link'];

if(isset($_SESSION['usercode']) & isset($_SESSION['user_email']) & isset($_SESSION['book'])){ $users = extract(get_user_details($_SESSION['user_email'])); } else{}
//echo "this is the user_code: ". $_SESSION['usercode'];
$find_title = $db->query("SELECT * FROM  books WHERE book_id ='".$_SESSION['book']."'  ");
$query_row = $find_title->fetch(PDO::FETCH_ASSOC);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Checkout - FEPFL Publications</title>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Foundation for Enhancement and Promotion of Family Life">
    <meta content="family, peace, marriage, home,  " name="description">

    <!-- Favicon -->
    <link href="../img/jjj/logo.png" rel="icon">

    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/font/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/font/css2.css">
    <link href="../assets/lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="../assets/lib/animate/animate.min.css" rel="stylesheet">
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <script src="../assets/js/sweetalert.min.js"></script>
    <script src="../assets/js/vanila_del_prompt.js"></script>
    <link href="../assets/css/style.css" rel="stylesheet">

    <!-- <link rel="stylesheet" type="text/css" href="css/local.css"> -->
    <link rel="stylesheet" type="text/css" href="../assets/css/sweetalert.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/vanila_del_prompt.css">
    <?php //include('nav/links.php'); ?>
    <link href="../assets/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/lib/css/style.css">
    <?php //include('../nav/links.php'); ?>
</head>

<body>
    <?php include('nav2.php'); ?>

    <!-- Page Header Start -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2> </h2>
                </div>
                <div class="col-12">
                    <a href="../index">Home</a>
                    <a href="../books">Books</a>
                    <a href="">Checkout</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Single Post Start-->
    <div class="single">
        <div class="container">
            <div class="row">
                <div class=" col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-6 pr-xl-0 pr-lg-0 pr-md-0  m-b-30">
                            <div class="product-slider">
                                <div id="productslider-1" class="product-carousel carousel slide" data-ride="carousel">
                                    <div class="carousel-inner">
                                        <img class="d-block" src="../master/<?php echo $query_row['book_img']; ?>" width="100%" alt="<?php echo $query_row['book_name']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 pl-xl-0 pl-lg-0 pl-md-0 border-left m-b-30">
                            <div class="product-details">
                                <div class="border-bottom pb-3 mb-3">
                                    <h2 class="mb-3"><?php echo $query_row['book_name']; ?></h2>
                                    <div class="product-rating d-inline-block float-right">
                                        <i class="fa fa-fw fa-star"></i>
                                        <i class="fa fa-fw fa-star"></i>
                                        <i class="fa fa-fw fa-star"></i>
                                        <i class="fa fa-fw fa-star"></i>
                                        <i class="fa fa-fw fa-star"></i>
                                    </div>
                                    <h3 class="mb-0 text-primary"><del>N</del> <?php echo $query_row['book_price']; ?></h3>
                                </div>
                                <div class="product-description">
                                    <h4 class="mb-1">Descriptions</h4>
                                    <form  action="" role="" method="POST">
                                        <?php  
                                        if(isset($_POST['pay'])){
                                            $_SESSION['email'] = $_POST['email'];
                                            $_SESSION['name'] = $_POST['name'];
                                            $_SESSION['book_name'] = $_POST['book_name'];
                                            $_SESSION['price'] = $_POST['price'];
                                            $_SESSION['ref'] = $_POST['ref'];
                                            $_SESSION['book_id'] = $_POST['book_id'];


                                            

                                            $insert = QueryDB("INSERT INTO payment VALUES('','".$_SESSION['ref']."','".$_SESSION['book_id']."','".time()."','".$_SESSION['price']."','".$_SESSION['email']."','pending',0,'".$query_row['book_path']."','".$_SESSION['book_name']."',0) ");
                                              if($insert){  header('location:pay3'); //die();
                                          }
                                      }

                                      ?>


                                      <div class="form-group row">
                                        <label for="inputEmail2" class="col-md-6 col-form-label text-right">Account Email</label>
                                        <div class="col-md-6">
                                            <input id="email-address" type="email" readonly="" value="<?php echo $email;  ?>" name="email" placeholder="Email" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputEmail2" class="col-md-6 col-form-label text-right">Account Name</label>
                                        <div class="col-md-6">
                                            <input id="" type="text" readonly="" name="name" value="<?php echo $fname; ?>" class="form-control">
                                        </div>
                                    </div><div class="form-group row">
                                        <label for="" class="col-md-6 col-form-label text-right">Book Name: </label>
                                        <div class="col-md-6">
                                            <input id="" type="text" name="book_name" readonly="" value="<?php echo $query_row['book_name']; ?>" class="form-control">
                                        </div>
                                    </div><div class="form-group row">
                                        <label for="inputEmail2" class="col-md-6 col-form-label text-right">Book Price</label>
                                        <div class="col-md-6">
                                            <input id="amount" type="text" name="price" readonly="" value="<?php echo $query_row['book_price']; ?>" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <input id="ref" type="hidden" readonly="" name="book_id"  value="<?php echo $query_row['book_id']; ?>" class="form-control">
                                            <input id="ref" type="hidden" readonly="" name="ref"  value="<?php echo post_id(); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-submit">
                                        <input type="submit" name="pay" value="Check Out" class="btn btn-primary btn-block btn-lg" >
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Single Post End-->   
<div class="footer bg-dark">
    <div class="container">
        <div class="row">
            <div class="container copyright  text-white">
                <div class="row">
                    <div class="col-md-6">
                        <p style="display: none">&copy; <a href="#">Your Site Name</a>, All Right Reserved.</p>
                        <p >Copyright &copy; <a href="https://www.familypeace247.org">Family Peace 247</a>, All Right Reserved <?php  echo date('Y'); ?>.</p>
                    </div>
                    <div class="col-md-6">
                        <p>Designed By <a href="https://wa.me/2349024945875" target="_blank">Brainpals Resources</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php //include('nav/scripts.php'); ?>

<!-- JavaScript Libraries -->
<script src="../assets/js/jquery-3.4.1.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/lib/easing/easing.min.js"></script>
<script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
<script src="../assets/lib/waypoints/waypoints.min.js"></script>
<script src="../assets/lib/counterup/counterup.min.js"></script>
<script src="../assets/lib/parallax/parallax.min.js"></script>
<script src="../assets/js/sweetalert.min.js"></script>
<script src="../assets/js/vanila_del_prompt.js"></script>
<script src="../assets/js/countries.js"></script>
<!-- Template Javascript -->
<script src="../assets/js/main.js"></script> 
<script src="../assets/js/parsley.js"></script>
<script src="../assets/js/xl-toast.js"></script>
<script>
    jQuery('<div class="quantity-nav"><div class="quantity-button quantity-up">+</div><div class="quantity-button quantity-down">-</div></div>').insertAfter('.quantity input');
    jQuery('.quantity').each(function() {
        var spinner = jQuery(this),
        input = spinner.find('input[type="number"]'),
        btnUp = spinner.find('.quantity-up'),
        btnDown = spinner.find('.quantity-down'),
        min = input.attr('min'),
        max = input.attr('max');

        btnUp.click(function() {
            var oldValue = parseFloat(input.val());
            if (oldValue >= max) {
                var newVal = oldValue;
            } else {
                var newVal = oldValue + 1;
            }
            spinner.find("input").val(newVal);
            spinner.find("input").trigger("change");
        });

        btnDown.click(function() {
            var oldValue = parseFloat(input.val());
            if (oldValue <= min) {
                var newVal = oldValue;
            } else {
                var newVal = oldValue - 1;
            }
            spinner.find("input").val(newVal);
            spinner.find("input").trigger("change");
        });
    });
</script>
</body>
</html>
