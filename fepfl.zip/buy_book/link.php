<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="Foundation for Enhancement and Promotion of Family Life">
<meta content="family, peace, marriage, home,  " name="description">

<!-- Favicon -->
<link href="../../../img/jjj/logo.png" rel="icon">

<!-- Google Font -->
<!-- <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet"> -->

<!-- CSS Libraries -->

<link href="../../../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../../../assets/css/font/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="../../../assets/css/font/css2.css">
<link href="../../../assets/lib/flaticon/font/flaticon.css" rel="stylesheet">
<link href="../../../assets/lib/animate/animate.min.css" rel="stylesheet">
<link href="../../../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

<!-- Template Stylesheet -->
<script src="../../../assets/js/sweetalert.min.js"></script>
<script src="../../../assets/js/vanila_del_prompt.js"></script>
<link href="../../../assets/css/style.css" rel="stylesheet">

<!-- <link rel="stylesheet" type="text/css" href="css/local.css"> -->
<link rel="stylesheet" type="text/css" href="../../../assets/css/sweetalert.css">
<link rel="stylesheet" type="text/css" href="../../../assets/css/vanila_del_prompt.css">
<?php //include('nav/links.php'); ?>
<link href="../../../assets/circular-std/style.css" rel="stylesheet">
<link rel="stylesheet" href="../../../assets/libs/css/style.css">