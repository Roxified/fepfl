<?php  ob_start(); session_start(); require '../db/config.php'; require '../db/functions.php';


//This will be set in my Call Back as pay-appreciation.php
$result = array();
//The parameter after verify/ is the transaction reference to be verified
//$url = 'https://api.paystack.co/transaction/verify/'.$_SESSION['reference_key'];

// $url = 'https://api.paystack.co/transaction/verify/'.$_SESSION['reference_key'];
$url = 'https://api.paystack.co/transaction/verify/'.$_GET['reference'];

//$url = 'https://api.paystack.co/transaction/verify/'.$_SESSION['reference_key'];


// sk_live_d9026248cea4af64389ccc9c2dfb6c2887f30c92
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt(
  $ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer sk_live_d9026248cea4af64389ccc9c2dfb6c2887f30c92']
  );
$request = curl_exec($ch);
curl_close($ch);
//https://developers.paystack.co/reference#verifying-transactions
if ($request) {
  $result = json_decode($request, true);
    // print_r($result);
  if($result){
    if($result['data']){
        //something came in
      if($result['data']['status'] == 'success'){

        if(QueryDB("UPDATE payment SET pay_status='Approved', confirm_time ='".time()."' where pay_id ='".$_GET['reference']."' ")){

          if(QueryDB("SELECT COUNT(*) FROM payment where pay_id ='".$_GET['reference']."'  ")->fetchColumn()>0){
            $getter = QueryDB("SELECT * FROM payment where pay_id ='".$_GET['reference']."'  ");
            $rows = $getter->fetch(PDO::FETCH_ASSOC);

            $get_user = get_user_details($rows['pay_user']);

            $book_id = $rows['pay_ref'];
            $dBuk = get_spef_book($book_id);


 // echo $dBuk['book_path'];



            $_SESSION['status'] = 1;
//send ebook here
// $booker = get_book_details($_SESSION['book_code']);
            $book_location ='../master/'.$dBuk['book_path'];
            $url = 'https://www.familypeace247.org/';


 require_once "Mail.php"; // PEAR Mail package
require_once ('Mail/mime.php'); // PEAR Mail_Mime packge

 $from = "noreply@familypeace247.org"; //enter your email address
 $to = $rows['pay_user']; //enter the email address of the contact your sending to
 $subject = "Congratulations on Successful Purchase of our Book"; // subject of your email


 $headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);

$text = ''; // text versions of email.
$html = '<html><head><style type="text/css"></style></head><body>
<div style="width:410px;background-color:#b80000;margin:auto;color:white;">
<center><br><img src="'.$url.'img/logo.png" style="width:130px;"></center>
<p style="padding:10px;text-align: center;">FEPFL BOOK STORE</p></div>
<div style="width:410px;margin:auto;">
<p style="padding:10px;text-align: center;font-weight: bold;">Dear  '.get_user_name($get_user['email']).',</p>
<h4 style="padding:10px;font-weight: lighter;">You have Successful Purchased a Book from Our Book Store <br> Kindly Open the attched Book to start enjoying your book.</h4>
<p style="padding:10px;font-weight: bold;"><br><br/> Best Regards, <br><br> Sales Unit <br> FEPFL, Nigeria.</p>
<p style="padding:10px;font-style: italic;margin-top: 30px;color:gray;border-top: 1px solid gray">This email was automatically generated, please do not reply. Kindly send your enquires to info@familypeace247.org
<br>'.date('l d M,Y',time()).'</p></div></body></html>';

$crlf = "\n";

$file_name =$book_location;
//echo 'File name is '. $file_name;

$mime = new Mail_mime($crlf);
$mime->setTXTBody($text);
$mime->setHTMLBody($html);
$mime->addAttachment($file_name);
//do not ever try to call these lines in reverse order
$body = $mime->get();
$headers = $mime->headers($headers);

$host = "localhost"; // your mail server i.e mail.mydomain.com
$username = "noreply@familypeace247.org"; //  your email address (same as webmail username)
$password = "NOreply01.,"; // your password (same as webmail password)

$smtp = Mail::factory('smtp', array ('host' => $host, 'auth' => true,
  'username' => $username,'password' => $password));

$mail = $smtp->send($to, $headers, $body);

if (PEAR::isError($mail)) {
  echo("<p>" . $mail->getMessage() . "</p>");
}
else {
//echo("<p>Message successfully sent!</p>");
// header("Location: http://www.example.com/");

}


header('location:confirm');
}else { 
//faile Transactions
  $_SESSION['status'] = 0;

  header('location:failure');


}

}



}else{
  echo $result['message'];
}

}else{
      //print_r($result);
  die("Something went wrong while trying to convert the request variable to json. Uncomment the print_r command to see what is in the result variable.");
}
}else{
    //var_dump($request);
  $_SESSION['donation_state'] = 0;
  header('location:creators/pay_message');

    //die("Something went wrong while executing curl. Uncomment the var_dump line above this line to see what the issue is.
     // Please check your CURL command to make sure everything is ok");


}

}

?>

