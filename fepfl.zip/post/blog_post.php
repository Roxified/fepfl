<?php  ob_start(); session_start(); require('../db/config.php'); require('../db/functions.php');

$get_title = $_REQUEST['link'];

$_SESSION['post'] = $get_title;
if(isset($_SESSION['usercode']) & isset($_SESSION['user_email'])){ $users = extract(get_user_details($_SESSION['user_email'])); } else{}
//echo "this is the user_code: ". $_SESSION['usercode'];
$find_title = $db->query("SELECT * FROM  posts WHERE post_id ='".$_SESSION['post']."'  ");
$query_row = $find_title->fetch(PDO::FETCH_ASSOC);

$link = 3; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>FEPFL Blog Post - Latest news from FEPFL</title>
    <?php include('../buy_book/link.php'); ?>

    <script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
</head>

<body>
    <?php include('nav.php'); ?>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v9.0" nonce="NnDuTV1N"></script>
    <!-- Page Header Start -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2><?php echo $query_row['post_title']; ?></h2>
                </div>
                <div class="col-12">
                    <a href="index">Home</a>
                    <a href="">Post Details</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Single Post Start-->
    <div class="single">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="single-content">
                      <!-- AddToAny BEGIN -->
                      <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                        <a class="a2a_button_facebook"></a>
                        <a class="a2a_button_twitter"></a>
                        <a class="a2a_button_whatsapp"></a>
                        <a class="a2a_button_telegram"></a>
                        <a class="a2a_button_google_gmail"></a>
                        <a class="a2a_button_pinterest"></a>
                        <a class="a2a_dd"></a>

                    </div>
                    <script async src="https://static.addtoany.com/menu/page.js"></script>
                    <div id="fb-root"></div>
                    <!-- AddToAny END -->

                    <h1><?php echo $query_row['post_title']; ?></h1>
                    
                    <p><i class="fa fa-clock"></i> <?php echo get_time_ago($query_row['post_date']); ?> | <i class="fa fa-link"></i> <?php echo get_cat_by_code($query_row['post_cat']); ?></p>

                    <img src="../../../master/<?php echo $query_row['post_img']; ?>" />

                    <div class="fb-share-button" data-href="../../../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>" data-layout="button_count" data-size="large"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Share</a></div>

                    <div class="text-justify"> <?php echo  htmlspecialchars_decode($query_row['post_content']); ?></div>
                </div>
                <div class="single-tags">
                    <?php foreach (get_cat() as $key) {extract($key);
                        ?>
                        <a href="../../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>"><?php echo $cat_name ?></a>
                    <?php  } ?>

                </div>

                <div class="single-comment">
                    <h2>3 Comments</h2>
                    <ul class="comment-list">
                        <li class="comment-item">
                            <div class="comment-body">
                                <div class="comment-img">
                                    <img src="../../../img/user.jpg" />
                                </div>
                                <div class="comment-text">
                                    <h3><a href="">Josh Dunn</a></h3>
                                    <span>01 Jan 2045 at 12:00pm</span>
                                    <p>
                                        Lorem ipsum dolor sit amet elit. Integer lorem augue purus mollis sapien, non eros leo in nunc. Donec a nulla vel turpis tempor ac vel justo. In hac platea dictumst. 
                                    </p>
                                    <a class="btn" href="">Reply</a>
                                </div>
                            </div>
                        </li>
                        <li class="comment-item">
                            <div class="comment-body">
                                <div class="comment-img">
                                    <img src="../../../img/user.jpg" />
                                </div>
                                <div class="comment-text">
                                    <h3><a href="">Josh Dunn</a></h3>
                                    <p><span>01 Jan 2045 at 12:00pm</span></p>
                                    <p>
                                        Lorem ipsum dolor sit amet elit. Integer lorem augue purus mollis sapien, non eros leo in nunc. Donec a nulla vel turpis tempor ac vel justo. In hac platea dictumst. 
                                    </p>
                                    <a class="btn" href="">Reply</a>
                                </div>
                            </div>
                            <ul class="comment-child">
                                <li class="comment-item">
                                    <div class="comment-body">
                                        <div class="comment-img">
                                            <img src="../../../img/user.jpg" />
                                        </div>
                                        <div class="comment-text">
                                            <h3><a href="">Josh Dunn</a></h3>
                                            <p><span>01 Jan 2045 at 12:00pm</span></p>
                                            <p>
                                                Lorem ipsum dolor sit amet elit. Integer lorem augue purus mollis sapien, non eros leo in nunc. Donec a nulla vel turpis tempor ac vel justo. In hac platea dictumst. 
                                            </p>
                                            <a class="btn" href="">Reply</a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="comment-form">
                    <h2>Leave a comment</h2>
                    <form>
                        <div class="form-group">
                            <label for="name">Name *</label>
                            <input type="text" class="form-control" id="name">
                        </div>
                        <div class="form-group">
                            <label for="email">Email *</label>
                            <input type="email" class="form-control" id="email">
                        </div>
                        <div class="form-group">
                            <label for="website">Website</label>
                            <input type="url" class="form-control" id="website">
                        </div>

                        <div class="form-group">
                            <label for="message">Message *</label>
                            <textarea id="message" cols="30" rows="5" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Post Comment" class="btn btn-custom">
                        </div>
                    </form>
                </div>

                <div class="single-related">
                    <h2>Related Post</h2>
                    <div class="owl-carousel related-slider">
                     <?php foreach (QueryDB("SELECT * FROM posts where post_status =1 and post_cat = '".$query_row['post_cat']."' ORDER BY RAND()  LIMIT 5 ") as $value) {extract($value);
                        ?>
                        <div class="post-item">
                            <div class="post-img">
                                <img src="../../../master/<?php echo $post_img; ?>" />
                            </div>
                            <div class="post-text">
                               <div class="post-meta">
                                <p><?php echo get_cat_by_code($post_cat); ?></p>
                            </div>
                            <a href="../../../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>"><?php echo $post_title; ?></a>

                        </div>
                        </div><?php }  ?>

                    </div>
                </div>

            </div>

            <div class="col-lg-4">
                <div class="sidebar">
                    <div class="sidebar-widget">
                        <div class="search-widget">
                            <form>
                                <input class="form-control" type="text" placeholder="Search Keyword">
                                <button class="btn"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                    </div>

                    <div class="sidebar-widget">
                        <h2 class="widget-title">Recent Post</h2>
                        <?php foreach (QueryDB("SELECT * FROM posts where post_status =1 ORDER BY id DESC  LIMIT 5 ") as $value) {extract($value);
                            ?>
                            <div class="recent-post">
                                <div class="post-item">
                                    <div class="post-img">
                                        <img src="../../../master/<?php echo $post_img; ?>" />
                                    </div>
                                    <div class="post-text">
                                        <a href="../../../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>"><?php echo $post_title; ?></a>
                                    </div>
                                </div>

                            </div>

                        <?php } ?>
                    </div>

                    <div class="sidebar-widget">
                        <div class="image-widget">
                         <img src="../../../master/<?php echo $query_row['post_img']; ?>" alt="Image">
                     </div>
                 </div>
                 <div class="sidebar-widget">
                    <h2 class="widget-title">Categories</h2>
                    <div class="category-widget">
                        <ul><?php foreach(get_cat() as $rows){extract($rows);  ?>
                            <li><a href="../../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>"><?php echo $cat_name;  ?></a><span>(<?php echo post_cat_counter($post_cat);  ?>)</span></li>
                        <?php } ?>

                    </ul>
                </div>
            </div>

                       <!--  <div class="sidebar-widget">
                            <div class="image-widget">
                                <a href="#"><img src="../../../img/blog-3.jpg" alt="Image"></a>
                            </div>
                        </div> -->

                        <div class="sidebar-widget">
                            <h2 class="widget-title">Tags Cloud</h2>
                            <div class="tag-widget">
                                <?php foreach (get_cat() as $key) {extract($key); ?>
                                    <a href="../../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>"><?php echo $cat_name;  ?></a><?php  } ?>
                                </div>
                            </div>
                            <div class="sidebar-widget">
                                <h2 class="widget-title">Recent Events</h2>
                                <?php foreach (QueryDB("SELECT * FROM events where status =0 ORDER BY id DESC  LIMIT 5 ") as $value) {extract($value);
                                    ?>
                                    <div class="recent-post">
                                        <div class="post-item">
                                            <div class="post-img">
                                                <img src="../../../master/<?php echo $img; ?>" />
                                            </div>
                                            <div class="post-text">
                                                <a href="../../../post/<?php echo $event_id; ?>/<?php echo strtolower(str_replace(' ', '-', $event_name)); ?>"><?php echo $event_name; ?></a>
                                            </div>
                                        </div>
                                        </div> <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Single Post End-->   

        <?php include('footer.php'); 
        include('scripts.php'); ?>
    </body>
    </html>
