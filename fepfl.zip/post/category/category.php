<?php  ob_start(); session_start(); require('../../db/config.php'); require('../../db/functions.php');

$get_title = $_REQUEST['link'];

$getter = get_cat_by_name($get_title);

$_SESSION['category'] = $getter;
if(isset($_SESSION['usercode']) & isset($_SESSION['user_email'])){ $users = extract(get_user_details($_SESSION['user_email'])); } else{ }
//echo "this is the user_code: ". $_SESSION['usercode'];
$find_title = QueryDB("SELECT * FROM  posts WHERE post_cat ='".$_SESSION['category']."'  ");

$query_row = $find_title->fetch(PDO::FETCH_ASSOC);

$link = 7; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>FEPFL Blog- Latest news from FEPFL</title>
    <?php include('../link.php'); ?>

    <script>
        function blinktext() {
          var f = document.getElementById('announcement');
          setInterval(function() {
            f.style.visibility = (f.style.visibility == 'hidden' ? '' : 'hidden');
        }, 750);
      }
  </script>
</head>

<body onload="blinktext();">
    <?php //include('../nav.php'); ?>
    <!-- Top Bar Start -->
    <div class="top-bar d-none d-md-block">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="top-bar-left">
                        <div class="text">
                         <a href="tel:234 806 5659 796"><i class="fa fa-phone-alt"></i>
                            <p>+234 806 5659 796</p></a>
                        </div>
                        <div class="text">
                            <i class="fa fa-envelope"></i>
                            <p>info@familypeace247.org</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="top-bar-right">
                        <div class="social">
                            <a href=""><i class="fab fa-twitter"></i></a>
                            <a href=""><i class="fab fa-facebook-f"></i></a>
                            <a href=""><i class="fab fa-linkedin-in"></i></a>
                            <a href=""><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top Bar End -->

    <!-- Nav Bar Start -->
    <div class="navbar navbar-expand-lg bg-dark navbar-dark">
        <div class="container-fluid">
            <a href="index" class="navbar-brand"><img src="../../img/logo.png"> FEPFL</a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto">
                    <a href="../../index" class="nav-item nav-link <?php if ($link==1){ echo "active"; } ?>">Home</a>
                    <a href="../../academy" class="nav-item nav-link <?php if ($link==2){ echo "active"; } ?>">Academy</a>
                    <a href="../../blog" class="nav-item nav-link <?php if ($link==2){ echo "active"; } ?>">Blog</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle <?php if ($link==3){ echo "active"; } ?>" data-toggle="dropdown">Categories</a>
                        <div class="dropdown-menu">
                            <?php foreach (get_cat() as $key) {extract($key); ?>
                                <a href="../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>" class="dropdown-item"><?php echo $cat_name ?></a>
                            <?php  }  ?>
                        </div>
                    </div>
                    <a href="../../books" class="nav-item nav-link <?php if ($link==7){ echo "active"; } ?>">Publications</a>

                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle <?php if ($link==4){ echo "active"; } ?>" data-toggle="dropdown">Events</a>
                        <div class="dropdown-menu">
                            <a href="../../event" class="dropdown-item">Upcoming</a>
                            <a href="../../event" class="dropdown-item">Outreaches</a>
                            <a href="../../event" class="dropdown-item">Seminars</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle <?php if ($link==5){ echo "active"; } ?>" data-toggle="dropdown" >About FEPFL</a>
                        <div class="dropdown-menu">
                            <a href="../../about" class="dropdown-item">Overview</a>
                            <a href="#" class="dropdown-item">What We Do</a>
                            <a href="#" class="dropdown-item">Meet The Team</a>
                            <a href="#" class="dropdown-item">Become A Volunteer</a>
                        </div>
                    </div>
                    <a href="../../contact" class="nav-item nav-link <?php if ($link==6){ echo "active"; } ?>">Contact</a>
                    <?php if(empty($_SESSION['usercode'])){ ?>
                        <a href="../../login" class="nav-item nav-link <?php if ($link==6){ echo "active"; } ?>"><i class="fa fa-user"></i> Login</a>
                        <a href="../../signup" class="nav-item nav-link <?php if ($link==6){ echo "active"; } ?>">Signup</a>
                    <?php  } else{                        ?>
                        <a href="../../logout" class="nav-item nav-link btn btn-danger"><i class="fa fa-cancel"></i> Logout</a> <?php }  ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Nav Bar End -->

        <!-- Page Header Start -->
        <div class="page-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>FEPFL Blog</h2>
                    </div>
                    <div class="col-12">
                        <a href="../../index">Home</a>
                        <a href="../../blog">Blog Post</a>
                        <a href="">Category</a>

                    </div>
                </div>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- Blog Start -->
        <div class="blog">
            <div class="container">
                <div class="section-header text-center">
                    <p>Our Blog</p>
                    <h2>Latest news & articles directly from our blog</h2>
                </div>

                <!-- Single Post Start-->
                <div class="single">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-9">
                                <div class="row">
                                    <?php if(QueryDB("SELECT COUNT(*) FROM posts where post_status =1 and post_cat='".$_SESSION['category']."' ")->fetchColumn()<1){ ?>


                                        <div class="section-header text-center" id="announcement" style="visibility: hidden;">
                                            <p>No Available Post for this Category Now</p>
                                        </div>


                                    <?php  } else{  foreach ( QueryDB("SELECT * FROM posts where post_status =1 and post_cat='".$_SESSION['category']."' ") as $rows ){ extract($rows); ?>
                                        <div class="section-header text-center d-none" id="announcement" style="visibility: hidden;">
                                            <p>No Available Post for this Category Now</p>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="blog-item">
                                                <div class="blog-img">
                                                    <a href="../../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>"><img src="../../master/<?php echo $post_img; ?>" alt="Image"></a>
                                                </div>
                                                <div class="blog-text">
                                                    <h3><a href="../../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>"><?php echo $post_title; ?></a></h3>
                                                    <p>
                                                        <?php echo substr(htmlspecialchars_decode($post_content), 0, 150);  ?>
                                                    </p><a href="../../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>" class="btn btn-danger">Read More</a>
                                                </div>
                                                <div class="blog-meta">
                                                    <p><i class="fa fa-clock"></i><?php echo get_time_ago($post_date); ?></p>
                                                    <p><i class="fa fa-link"></i><?php echo get_cat_by_code($post_cat); ?></p>
                                                </div>
                                            </div>
                                        </div>

                                    <?php } ?>

                                    <div class="col-12">
                                        <ul class="pagination justify-content-center">
                                            <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                                            <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                        </ul>
                                    </div>
                                <?php   } ?>
                            </div>
                            <div class="single-tags">
                                <?php foreach (get_cat() as $key) {extract($key); ?>
                                    <a href="../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>"><?php echo $cat_name ?></a> <?php  } ?>
                                </div>
                                <div class="single-related">
                                    <h2>Related Post</h2>
                                    <div class="owl-carousel related-slider">
                                        <?php foreach (QueryDB("SELECT * FROM posts where post_status =1 ORDER BY RAND()  LIMIT 5 ") as $value) {extract($value);  ?>
                                            <div class="post-item">
                                                <div class="post-img">
                                                    <img src="../../master/<?php echo $post_img; ?>" />
                                                </div>
                                                <div class="post-text">
                                                    <div class="post-meta">
                                                        <p><?php echo get_cat_by_code($post_cat); ?></p>
                                                    </div>
                                                    <a href="../../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>"><?php echo $post_title; ?></a>
                                                </div>
                                                </div> <?php }  ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <div class="sidebar">
                                            <div class="sidebar-widget">
                                                <div class="search-widget">
                                                    <form>
                                                        <input class="form-control" type="text" placeholder="Search Keyword">
                                                        <button class="btn"><i class="fa fa-search"></i></button>
                                                    </form>
                                                </div>
                                            </div>

                                            <div class="sidebar-widget">
                                                <h2 class="widget-title">Recent Post</h2>
                                                <?php foreach (QueryDB("SELECT * FROM posts where post_status =1 ORDER BY id DESC  LIMIT 5 ") as $value) {extract($value);
                                                    ?>
                                                    <div class="recent-post">
                                                        <div class="post-item">
                                                            <div class="post-img">
                                                                <img src="../../master/<?php echo $post_img; ?>" />
                                                            </div>
                                                            <div class="post-text">
                                                                <a href="../../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>"><?php echo $post_title; ?></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                            <div class="sidebar-widget">
                                                <h2 class="widget-title">Categories</h2>
                                                <div class="category-widget">
                                                    <ul><?php foreach(get_cat() as $rows){extract($rows);  ?>
                                                        <li><a href="../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>"><?php echo $cat_name;  ?></a><span>(<?php echo post_cat_counter($post_cat);  ?>)</span></li> <?php } ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="sidebar-widget">
                                                <h2 class="widget-title">Tags Cloud</h2>
                                                <div class="tag-widget">
                                                    <?php foreach (get_cat() as $key) {extract($key);
                                                        ?>
                                                        <a href="../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>"><?php echo $cat_name;  ?></a>
                                                    <?php  } ?>
                                                </div>
                                            </div>
                                            <div class="sidebar-widget">
                                                <h2 class="widget-title">Recent Events</h2>
                                                <?php foreach (QueryDB("SELECT * FROM events where status =0 ORDER BY id DESC  LIMIT 5 ") as $value) {extract($value);
                                                    ?>
                                                    <div class="recent-post">
                                                        <div class="post-item">
                                                            <div class="post-img">
                                                                <img src="../../master/<?php echo $img; ?>" />
                                                            </div>
                                                            <div class="post-text">
                                                                <a href="../../post/<?php echo $event_id; ?>/<?php echo strtolower(str_replace(' ', '-', $event_name)); ?>"><?php echo $event_name; ?></a>
                                                            </div>
                                                        </div>
                                                        </div> <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Single Post End-->   

                        <?php include('../footer.php'); 
                        include('scripts.php'); ?>
                    </body>
                    </html>
