<?php  ob_start(); session_start(); require('../db/config.php'); require('../db/functions.php');

$get_title = $_REQUEST['link'];

$_SESSION['event'] = $get_title;
if(isset($_SESSION['usercode']) & isset($_SESSION['user_email'])){ $users = extract(get_user_details($_SESSION['user_email'])); } else{}
//echo "this is the user_code: ". $_SESSION['usercode'];
$find_title = $db->query("SELECT * FROM  events WHERE  event_id='".$_SESSION['event']."'  ");
$query_row = $find_title->fetch(PDO::FETCH_ASSOC);

$link = 3; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>FEPFL Events - Latest news from FEPFL</title>
    <?php include('link.php'); ?>

    <script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
</head>

<body>
    <?php include('nav2.php'); ?>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v9.0" nonce="NnDuTV1N"></script>
    <!-- Page Header Start -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2><?php echo $query_row['event_name']; ?></h2>
                </div>
                <div class="col-12">
                    <a href="../../index">Home</a>
                    <a href="../../event">Events</a>
                    <a href=""><?php echo $query_row['event_name']; ?></a>

                </div>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Single Post Start-->
    <div class="single">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="single-content">
                      <!-- AddToAny BEGIN -->
                      <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                        <a class="a2a_button_facebook"></a>
                        <a class="a2a_button_twitter"></a>
                        <a class="a2a_button_whatsapp"></a>
                        <a class="a2a_button_telegram"></a>
                        <a class="a2a_button_google_gmail"></a>
                        <a class="a2a_button_pinterest"></a>
                        <a class="a2a_dd"></a>

                    </div>
                    <script async src="https://static.addtoany.com/menu/page.js"></script>
                    <div id="fb-root"></div>
                    <!-- AddToAny END -->

                    <h1><?php echo $query_row['event_name']; ?></h1>
                    <p><i class="fa fa-calendar-alt"></i><?php  echo date('d', strtotime($query_row['startDate'])); ?>-<?php  echo date('d M Y', strtotime($query_row['endDate'])); ?> </p>
                    <p><i class="far fa-clock"></i><?php  echo date('h:i A',strtotime($query_row['startTime'])); ?> - <?php  echo date('h:i A',strtotime($query_row['endTime'])); ?></p>

                    <img src="../../master/<?php echo $query_row['img']; ?>" />

                    <div class="fb-share-button" data-href="../../post/<?php echo $event_id; ?>/<?php echo strtolower(str_replace(' ', '-', $event_name)); ?>" data-layout="button_count" data-size="large"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Share</a></div>

                    <div class="text-justify"> <?php echo  htmlspecialchars_decode($query_row['event_desc']); ?></div>
                </div>
                <div class="single-tags">
                    <?php foreach (get_cat() as $key) {extract($key);
                        ?>
                        <a href="../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>"><?php echo $cat_name ?></a>
                    <?php  } ?>

                </div>

                <div class="single-comment">
                    <h2>3 Comments</h2>
                    <ul class="comment-list">
                        <li class="comment-item">
                            <div class="comment-body">
                                <div class="comment-img">
                                    <img src="../../img/user.jpg" />
                                </div>
                                <div class="comment-text">
                                    <h3><a href="">Josh Dunn</a></h3>
                                    <span>01 Jan 2045 at 12:00pm</span>
                                    <p>
                                        Lorem ipsum dolor sit amet elit. Integer lorem augue purus mollis sapien, non eros leo in nunc. Donec a nulla vel turpis tempor ac vel justo. In hac platea dictumst. 
                                    </p>
                                    <a class="btn" href="">Reply</a>
                                </div>
                            </div>
                        </li>
                        <li class="comment-item">
                            <div class="comment-body">
                                <div class="comment-img">
                                    <img src="../../img/user.jpg" />
                                </div>
                                <div class="comment-text">
                                    <h3><a href="">Josh Dunn</a></h3>
                                    <p><span>01 Jan 2045 at 12:00pm</span></p>
                                    <p>
                                        Lorem ipsum dolor sit amet elit. Integer lorem augue purus mollis sapien, non eros leo in nunc. Donec a nulla vel turpis tempor ac vel justo. In hac platea dictumst. 
                                    </p>
                                    <a class="btn" href="">Reply</a>
                                </div>
                            </div>
                            <ul class="comment-child">
                                <li class="comment-item">
                                    <div class="comment-body">
                                        <div class="comment-img">
                                            <img src="../../img/user.jpg" />
                                        </div>
                                        <div class="comment-text">
                                            <h3><a href="">Josh Dunn</a></h3>
                                            <p><span>01 Jan 2045 at 12:00pm</span></p>
                                            <p>
                                                Lorem ipsum dolor sit amet elit. Integer lorem augue purus mollis sapien, non eros leo in nunc. Donec a nulla vel turpis tempor ac vel justo. In hac platea dictumst. 
                                            </p>
                                            <a class="btn" href="">Reply</a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="comment-form">
                    <h2>Leave a comment</h2>
                    <form>
                        <div class="form-group">
                            <label for="name">Name *</label>
                            <input type="text" class="form-control" id="name">
                        </div>
                        <div class="form-group">
                            <label for="email">Email *</label>
                            <input type="email" class="form-control" id="email">
                        </div>
                        <div class="form-group">
                            <label for="website">Website</label>
                            <input type="url" class="form-control" id="website">
                        </div>

                        <div class="form-group">
                            <label for="message">Message *</label>
                            <textarea id="message" cols="30" rows="5" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Post Comment" class="btn btn-custom">
                        </div>
                    </form>
                </div>

                <div class="single-related">
                    <h2>Related Post</h2>
                    <div class="owl-carousel related-slider">
                        <?php foreach (QueryDB("SELECT * FROM events where status =0  ORDER BY RAND()  LIMIT 5 ") as $value) {extract($value);
                            ?>
                            <div class="post-item">
                                <div class="post-img">
                                    <img src="../../master/<?php echo $img; ?>" />
                                </div>
                                <div class="post-text">

                                    <a href="../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>"><?php echo $event_name; ?></a>

                                </div>
                                </div><?php }  ?>

                            </div>
                        </div>

                    </div>

                    <div class="col-lg-4">
                        <div class="sidebar">
                            <div class="sidebar-widget">
                                <div class="search-widget">
                                    <form>
                                        <input class="form-control" type="text" placeholder="Search Keyword">
                                        <button class="btn"><i class="fa fa-search"></i></button>
                                    </form>
                                </div>
                            </div>

                            <div class="sidebar-widget">
                                <h2 class="widget-title">Recent Post</h2>
                                <?php foreach (QueryDB("SELECT * FROM posts where post_status =1 ORDER BY id DESC  LIMIT 5 ") as $value) {extract($value);
                                    ?>
                                    <div class="recent-post">
                                        <div class="post-item">
                                            <div class="post-img">
                                                <img src="../../master/<?php echo $post_img; ?>" />
                                            </div>
                                            <div class="post-text">
                                                <a href="../../post/<?php echo $post_id; ?>/<?php echo date('Y',$post_date); ?>/<?php echo strtolower(str_replace(' ', '-', $post_title)); ?>"><?php echo $post_title; ?></a>
                                            </div>
                                        </div>

                                    </div>

                                <?php } ?>
                            </div>

                            <div class="sidebar-widget">
                                <div class="image-widget">
                                 <img src="../../master/<?php echo $query_row['img']; ?>" alt="Image">
                             </div>
                         </div>
                         <div class="sidebar-widget">
                            <h2 class="widget-title">Categories</h2>
                            <div class="category-widget">
                                <ul><?php foreach(get_cat() as $rows){extract($rows);  ?>
                                    <li><a href="../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>"><?php echo $cat_name;  ?></a><span>(<?php echo post_cat_counter($post_cat);  ?>)</span></li>
                                <?php } ?>

                            </ul>
                        </div>
                    </div>

                       <!--  <div class="sidebar-widget">
                            <div class="image-widget">
                                <a href="#"><img src="../../../img/blog-3.jpg" alt="Image"></a>
                            </div>
                        </div> -->

                        <div class="sidebar-widget">
                            <h2 class="widget-title">Tags Cloud</h2>
                            <div class="tag-widget">
                                <?php foreach (get_cat() as $key) {extract($key); ?>
                                    <a href="../../post/category/<?php echo str_replace(' ', '-', strtolower($cat_name)); ?>"><?php echo $cat_name;  ?></a><?php  } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Single Post End-->   

<?php include('footer.php'); //include('scripts.php'); ?>
<!-- JavaScript Libraries -->
<script src="../../assets/js/jquery-3.4.1.min.js"></script>
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/lib/easing/easing.min.js"></script>
<script src="../../assets/lib/owlcarousel/owl.carousel.min.js"></script>
<script src="../../assets/lib/waypoints/waypoints.min.js"></script>
<script src="../../assets/lib/counterup/counterup.min.js"></script>
<script src="../../assets/lib/parallax/parallax.min.js"></script>
<script src="../../assets/js/sweetalert.min.js"></script>
<script src="../../assets/js/vanila_del_prompt.js"></script>
<script type="text/javascript" src="../../assets/js/countries.js"></script>
<!-- Template Javascript -->
<script src="../../assets/js/main.js"></script> 
<script type="text/javascript" src="../../assets/js/parsley.js"></script>
<script src="../../assets/js/xl-toast.js"></script>

<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-6013ee9050342d71"></script>

<script>

    $('#state').on('change',function () {
    //alert('Changed');
    var get_id =  $(this).find('option:selected').attr('id');
    //alert(get_id);
    get_country  = $("#country").val();
    // alert(get_id + get_country);
    if(get_country=='Nigeria'){
        $.ajax({url: 'get_state', type: 'POST',data: {stateIdLGA: get_id},success: function (result) {
            $('#lga').html(result); }  });
    }
})

    $("#country").on('change', function () {
      var getId =  $(this).find('option:selected').attr('id'); getValue = $(this).val(); 
  if(getValue=='Nigeria'){ //$('#postal').hide();
  // $('.stretch').removeClass('col-md-6');    $('.stretch').addClass('col-md-12');
  $.ajax({url: 'get_state', type: 'POST',data: {stateIdN: getId},success: function (result) {
    $('#state').html(result);
    // alert(result);
}  });

}else{
    $('#lga').remove();
    $('#lga2').remove();
    $.ajax({url: 'get_state', type: 'POST',data: {stateId: getId},success: function (result) {
        $('#state').html(result);
    // alert(result);

}

});
}


});
</script>

</body>
</html>
