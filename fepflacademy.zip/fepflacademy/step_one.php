<?php ob_start();
session_start();
require('db/config.php');
require('db/functions.php');
if (isset($_SESSION['std_email'])) {
  $std = get_stud_details($_SESSION['std_email']);
  extract($std);
  $pg = get_prog_det($std['std_id']);
  extract($pg);
} else {
  header("location:login");
}

?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta http-equiv="Content-Language" content="en" />
  <meta name="msapplication-TileColor" content="#2d89ef">
  <meta name="theme-color" content="#4188c9">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="HandheldFriendly" content="True">
  <meta name="MobileOptimized" content="320">
  <link rel="icon" href="favicon.ico" type="image/x-icon" />
  <link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
  <!-- Generated: 2018-04-06 16:27:42 +0200 -->
  <title>Homepage - FEPFL Marriage Academy</title>
  <?php include('link.php'); ?>
</head>

<body class="">
  <div class="page">
    <div class="page-main">
      <?php include('header.php'); ?>
      <?php if (prog_code($pg['prog_id']) == 1) { ?>
        <div class="my-3 my-md-5">
          <div class="container">
            <div class="page-header">
              <h1 class="page-title text-center">
                Welcome, <?php echo $std['std_fname']; ?> You have applying for the <?php echo prog_code($pg['prog_id']); ?> for the first level of the </ </h1>
            </div>


            <div class="row  align-items-center text-center">

              <div class="col-md-12">
                <h3>To have access to your learning portal, kindly complete your payment for form</h3>
              </div>

              <div class="col-md-6">
                <a href="#payment" data-toggle="modal" data-target="#payment" class="btn btn-primary text-center">Make Payments </a>
              </div>

            </div>
          </div>
        </div>
      <?php } ?>
      <footer class="footer">
        <div class="container">
          <div class="row align-items-center ">
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
              <p class="text-center">Copyright © <?php echo date('Y'); ?> <a href="https://familypeace247.org">FEPFL Marriage Academy</a></p>
            </div>
          </div>
        </div>
      </footer>
    </div>

    <div class="modal fade" id="payment" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <!-- <span aria-hidden="true">&times;</span> -->
            </button>
            <!-- 16:9 aspect ratio -->
            <div class="">
              <h4 class="text-center">Select Payment Method</h4>
              <div class="card">
                <a href="formPayment.php?ref=<?php echo md5($_SESSION['std_email']); ?>&email=<?php echo $_SESSION['std_email']; ?>" style="text-decoration: none;">
                  <div class="card-body">
                    <div class="media">
                      <span class="avatar avatar-xxl mr-5" style=""><i class="fa fa-credit-card"></i></span>
                      <div class="media-body">
                        <h4 class="m-0">PayStack</h4>
                        <p class="text-muted mb-0">Complete your payments using the paystack platform with ypur Master or VISA ATM Charge.</p>

                      </div>
                    </div>
                  </div>
                </a>
              </div>
              <div class="card">
                <a href="#" style="text-decoration: none;">
                  <div class="card-body">
                    <div class="media">
                      <span class="avatar avatar-xxl mr-5" style=""><i class="fa fa-credit-card"></i></span>
                      <div class="media-body">
                        <h4 class="m-0">Flutterwave</h4>
                        <p class="text-muted mb-0">Complete your payments using the paystack platform with ypur Master or VISA ATM Charge.</p>

                      </div>
                    </div>
                  </div>
                </a>
              </div>
              <div class="card">
                <a href="#" style="text-decoration: none;">
                  <div class="card-body">
                    <div class="media">
                      <span class="avatar avatar-xxl mr-5" style=""><i class="fa fa-credit-card"></i></span>
                      <div class="media-body">
                        <h4 class="m-0">Bank Transfer</h4>
                        <p class="text-muted mb-0">Complete your payments by paying into the bank. You transaction will be processed with 24hours.</p>

                      </div>
                    </div>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>



</body>

</html>