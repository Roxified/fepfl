<script src="assets/sweetalert.min.js"></script>
<script src="assets/vanila_del_prompt.js"></script>
<script src="assets/js/vendors/jquery-3.2.1.min.js"></script>
<script src="assets/js/require.min.js"></script>

<script>
  requirejs.config({
    baseUrl: '.'
  });
</script>
<script src="assets/js/dashboard.js"></script>
<script src="assets/plugins/charts-c3/plugin.js"></script>
<script src="assets/plugins/maps-google/plugin.js"></script>
<script src="assets/plugins/input-mask/plugin.js"></script>



<script>
  $('#state').on('change', function() {
    //alert('Changed');
    var get_id = $(this).find('option:selected').attr('id');
    //alert(get_id);

    $.ajax({
      url: 'get_state',
      type: 'POST',
      data: {
        stateIdLGA: get_id
      },
      success: function(result) {
        $('#lga').html(result);
      }
    });
  })

  $("#country").on('change', function() {
    var getId = $(this).find('option:selected').attr('id');
    getValue = $(this).val();

    if (getValue == 'Nigeria') { //$('#postal').hide();
      // $('.stretch').removeClass('col-md-6');    $('.stretch').addClass('col-md-12');
      $.ajax({
        url: 'get_state',
        type: 'POST',
        data: {
          stateIdN: getId
        },
        success: function(result) {
          $('#state').html(result);
          // alert(result);
        }
      });

    } else {
      $('#lga').remove();
      $.ajax({
        url: 'get_state',
        type: 'POST',
        data: {
          stateId: getId
        },
        success: function(result) {
          $('#state').html(result);
          // alert(result);
        }
      });
    }
  });
</script>