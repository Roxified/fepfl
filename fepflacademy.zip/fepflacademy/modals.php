    <div class="modal fade" id="payment3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog" role="document">
      <div class="modal-content">
       <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
        <div class="">
         <h2 class="text-center">Form Payment for Single Batch Study</h2>
         <h4 class="text-center"><b style="color:red">Note: Select Payment Method Below</b></h4>
         <div class="card">
          <div class="card-body">
           <div class="media">
            <span class="avatar avatar-xxl mr-5" style=""><i class="fa fa-credit-card"></i></span>
            <div class="media-body">
             <h4 class="m-0">PayStack Online Payment</h4>
             <p class="text-muted mb-0">Complete your payments using the paystack online platform with ypur Master or VISA ATM Charge.</p>
            </div>
           </div>
           <form class="card" action="" method="post">
            <?php if (isset($_POST['pay'])) {
             $level = $_POST['level'];
             $mode = 'Single';
             $price = get_price_by_id($level);
             $pay_id = rand();
             $ref = md5($_SESSION['std_email']);

             if (QueryDB("INSERT INTO fpay (pay_id, pay_ref, pay_time, price, pay_user, pay_status, confirm_time, mode, others, sem)
                                  VALUES('$pay_id','$ref','" . time() . "',
'$price','" . $_SESSION['std_email'] . "','pending',0,'$level',0,0 ) ")) {
              $_SESSION['price'] = $price;
              $_SESSION['ref'] = $ref;
              header('location:formPayment');
             } else {
              print "<script>alert('Transaction Failed'); windows.location='index'</script>";
             }
            }
            ?>
            <div class="card-body">
             <div class="form-group">
              <label class="form-label">Select Certificate Level</label>
              <select name="level" id="" class="form-control">
               <option value="">[Choose Certificate Level]</option>
               <?php foreach (QueryDB("SELECT * FROM prog where prog_mode='Single' and prog_id!='FULLS'  ") as $pt) {
                extract($pt); ?>
                <option value="<?php echo $prog_id; ?>"><?php echo $prog_name . ' (' . $prog_form . ')'; ?></option>
               <?php } ?>
              </select>
             </div>
             <div class="form-group">
              <input type="submit" class="btn btn-danger btn-block form-control" name="pay" value="Proceed to Pay">
             </div>
            </div>
           </form>
          </div>
         </div>
        </div>
        <div class="card">

         <div class="card-body">
          <div class="media">
           <span class="avatar avatar-xxl mr-5" style=""><i class="fa fa-credit-card"></i></span>
           <div class="media-body">
            <h4 class="m-0">Bank Transfer</h4>
            <p class="text-muted mb-0">Complete your payments by paying into the FEPFL Marriage Academy bank.<br><b>Account Name: FEPFL Marriage Academy <br>Account Number: 1024653058 <br></b> You transaction will be processed with 24hours.</p>
           </div>
          </div>
         </div>

        </div>
       </div>
      </div>
     </div>
    </div>
    </div>

    <div class="modal fade" id="payment1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog" role="document">
      <div class="modal-content">
       <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
        <div class="">
         <h2 class="text-center">Payment for Full-Time Single Study Mode</h2>
         <h4 class="text-center"><b style="color:red">Note: You are paying the sum of <del>N</del>2000 as your form fee</b><br>Select Payment Method</h4>
         <div class="card">
          <a href="verify.php?pay_id=<?php echo rand(); ?>&ref=<?php echo md5($_SESSION['std_email']); ?>&mode=Full&type=1&price=2000" style="text-decoration: none;">
           <div class="card-body">
            <div class="media">
             <span class="avatar avatar-xxl mr-5" style=""><i class="fa fa-credit-card"></i></span>
             <div class="media-body">
              <h4 class="m-0">PayStack</h4>
              <p class="text-muted mb-0">Complete your payments using the paystack platform with ypur Master or VISA ATM Charge.</p>
             </div>
            </div>
           </div>
          </a>
         </div>
         <div class="card">
          <a href="#" style="text-decoration: none;">
           <div class="card-body">
            <div class="media">
             <span class="avatar avatar-xxl mr-5" style=""><i class="fa fa-credit-card"></i></span>
             <div class="media-body">
              <h4 class="m-0">Bank Transfer</h4>
              <p class="text-muted mb-0">Complete your payments by paying into the FEPFL Marriage Academy bank.<br><b>Account Name: FEPFL Marriage Academy <br>Account Number: 1024653058 <br></b> You transaction will be processed with 24hours.</p>
             </div>
            </div>
           </div>
          </a>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>