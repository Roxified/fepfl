<?php ob_start();
session_start();
require('db/config.php');
require('db/functions.php');
if (isset($_SESSION['std_email'])) {
    $std = get_stud_details($_SESSION['std_email']);
    extract($std);


    //error_reporting(0);
} else {
    header("location:login");
}
$link = 1;
?>

    <?php if (isset($_POST['updlvs'])) {
        $_SESSION['cert_type'];
        $_SESSION['study_mode'];
        $_SESSION['student_type'];

        $email = $_SESSION['std_email'];
        $title = $_POST['title'];
        $oname = $_POST['oname'];
        $gender = $_POST['gender'];
        $age = $_POST['age'];
        $phone = $_POST['phone'];
        $country = $_POST['country'];
        $state = $_POST['state'];
        $lga = $_POST['lga'];
        $postal = $_POST['postal'];
        $religion = $_POST['religion'];
        $qual = $_POST['qual'];
        $job = $_POST['job'];
        $desg = $_POST['desg'];
        $plac = $_POST['plac'];
        $std_id = get_last_num();
        if (QueryDB("SELECT COUNT(*) FROM rstudents where std_email='$email' ")->fetchColumn() > 0) {
            print "<script>swal({text:'Form Filled',type:'sucess', title:'Completed'}, function(){ window.location = 'index'});</script>";
        }
        if (QueryDB("INSERT INTO rstudents (std_id, std_level, std_country, std_state, std_lga, std_addr, std_religion, std_email, std_qual, std_job, std_jobp, std_desg, std_iden, std_m, std_mstat, std_myrs, std_noc, std_mtype, std_mdate, std_mcode, std_mdoc, std_passport, reg_date, status
) VALUES('$std_id','" . $_SESSION['cert_type'] . "','$country','$state','$lga','$postal','$religion','$email','$qual','$job','$plac','$desg','','','',0,0,0,'','','','','" . time() . "',0) ") && QueryDB("UPDATE students SET std_oname='$oname', std_title='$title', std_sex='$gender', std_age='$age', std_phone='$phone' where std_email='$email' ")) {
            print "<script>swal({text:'Form Filled',type:'sucess', title:'Completed'}, function(){ window.location = 'index'});</script>";
        } else {
            print "<script>swal({text:'Not suceessful',type:'danger', title:'Error Occured'}, function(){ window.location = 'index'});</script>";
        }
    }




    ?>
