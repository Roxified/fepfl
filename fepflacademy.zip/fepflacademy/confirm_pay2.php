<?php ob_start();
session_start();
require('db/config.php');
require('db/functions.php');


//This will be set in my Call Back as pay-appreciation.php
$result = array();
//The parameter after verify/ is the transaction reference to be verified
//$url = 'https://api.paystack.co/transaction/verify/'.$_SESSION['reference_key'];

// $url = 'https://api.paystack.co/transaction/verify/'.$_SESSION['reference_key'];
$url = 'https://api.paystack.co/transaction/verify/' . $_GET['reference'];

//$url = 'https://api.paystack.co/transaction/verify/'.$_SESSION['reference_key'];

//sk_live_dd2369c9f75ed6482326823da282becbd154e233
//sk_test_9595d4bbb11005da8ec74118e55c91776549f012
// sk_test_1249da60de445f3622d87a3ce44f30a25a31eaea
// sk_test_fa2294dd7c7a14fe43e3a04d8c0181d7ade82165
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt(
  $ch,
  CURLOPT_HTTPHEADER,
  [
    'Authorization: Bearer sk_test_fa2294dd7c7a14fe43e3a04d8c0181d7ade82165 '
  ]
);
$request = curl_exec($ch);
curl_close($ch);
//https://developers.paystack.co/reference#verifying-transactions
if ($request) {
  $result = json_decode($request, true);
  // print_r($result);
  if ($result) {
    if ($result['data']) {
      //something came in
      if ($result['data']['status'] == 'success') {

        ///////////////////FORM PAYMENTS STARTS HERE////////////////////////

        if (QueryDB("SELECT COUNT(*) FROM fpay where pay_id ='" . $_GET['reference'] . "' ")->fetchColumn() > 0) {

          if (QueryDB("UPDATE fpay SET pay_status='Approved', confirm_time ='" . time() . "' where pay_id ='" . $_GET['reference'] . "' ")) {


            $getter = QueryDB("SELECT * FROM fpay where pay_id ='" . $_GET['reference'] . "'  ");
            $rows = $getter->fetch(PDO::FETCH_ASSOC);
            $_SESSION['ref'] = $_GET['reference'];
            $get_user = get_user_details($rows['pay_user']);
            $_SESSION['std_email'] = $rows['pay_user'];
            //  $book_id = $rows['pay_ref'];
            //  $dBuk = get_spef_book($book_id);

            $_SESSION['status'] = 1;
            //send ebook here
            // $booker = get_book_details($_SESSION['book_code']);
            //  $book_location = 'master/' . $dBuk['book_path'];
            $url =   'https://familypeace247.org/';

            require_once "Mail.php"; // PEAR Mail package
            require_once('Mail/mime.php'); // PEAR Mail_Mime packge

            $from = "noreply@familypeace247.org"; //enter your email address
            $to = $rows['pay_user']; //enter the email address of the contact your sending to
            $subject = "Form Payment For FEPFL Marraiage Academy"; // subject of your email

            $headers = array('From' => $from, 'To' => $to, 'Subject' => $subject);

            $text = ''; // text versions of email.
            $html = '<html><head><style type="text/css"></style></head><body>
<div style="width:410px;background-color:#09a0da; margin:auto;color:white;">
<center><br><img src="' . $url . 'images/logos/it_logo.png" style="width:130px;"></center>
<p style="padding:10px;text-align: center;">SPOTTABLE BOOK STORE</p></div>
<div style="width:410px;margin:auto;">
<p style="padding:10px;text-align: center;font-weight: bold;">Dear  ' . get_fname($rows['pay_user']) . ',</p>
<p style="padding:10px;">Your form payment of ' . $rows['price'] . ' was successful from FEPFL Marriage Academy <br><br>
Kindly Login to your student portal to fill in your information.</p>

<p style="padding:10px;font-weight: bold;"><br><br/> Best Regards, <br><br> Accounts Unit <br> FEPFL Marriage Academy.</p>
<p style="padding:10px;font-style: italic;margin-top: 30px;border-top: 1px solid #09a0da">This email was automatically generated, please do not reply. Kindly send your enquires to fepflmarriageacademy@gmail.com
<br>' . date('l d M,Y', time()) . '</p></div></body></html>';

            $crlf = "\n";

            $file_name = $book_location;
            //echo 'File name is '. $file_name;

            $mime = new Mail_mime($crlf);
            $mime->setTXTBody($text);
            $mime->setHTMLBody($html);
            //  $mime->addAttachment($file_name);
            //do not ever try to call these lines in reverse order
            $body = $mime->get();
            $headers = $mime->headers($headers);

            $host = "localhost"; // your mail server i.e mail.mydomain.com
            $username = "noreply@familypeace247.org"; //  your email address (same as webmail username)
            $password = "NOreply01.,"; // your password (same as webmail password)

            $smtp = Mail::factory('smtp', array(
              'host' => $host, 'auth' => true,
              'username' => $username, 'password' => $password
            ));

            $mail = $smtp->send($to, $headers, $body);

            if (PEAR::isError($mail)) {
              echo ("<p>" . $mail->getMessage() . "</p>");
            } else {
              //echo("<p>Message successfully sent!</p>");
              // header("Location: http://www.example.com/");
              $_SESSION['ref'] = $_GET['reference'];

              $_SESSION['std_email'] = $rows['pay_user'];
              header('location:index');
            }
          } else {
            //faile Transactions
            $_SESSION['status'] = 0;

            header('location:failure');
          }
        }


        ///////////////////SCHOOL FEES PAYMENTS STARTS HERE////////////////////////

        if (QueryDB("SELECT COUNT(*) FROM schpay where pay_id ='" . $_GET['reference'] . "' ")->fetchColumn() > 0) {

          if (QueryDB("UPDATE schpay SET pay_status='Approved', confirm_time ='" . time() . "' where pay_id ='" . $_GET['reference'] . "' ")) {


            $getter = QueryDB("SELECT * FROM schpay where pay_id ='" . $_GET['reference'] . "'  ");
            $rows = $getter->fetch(PDO::FETCH_ASSOC);
            $_SESSION['ref'] = $_GET['reference'];
            $get_user = get_user_details($rows['pay_user']);
            $_SESSION['std_email'] = $rows['pay_user'];
            //  $book_id = $rows['pay_ref'];
            //  $dBuk = get_spef_book($book_id);

            $_SESSION['status'] = 1;
            //send ebook here
            // $booker = get_book_details($_SESSION['book_code']);
            //  $book_location = 'master/' . $dBuk['book_path'];
            $url =   'https://familypeace247.org/';


            require_once "Mail.php"; // PEAR Mail package
            require_once('Mail/mime.php'); // PEAR Mail_Mime packge

            $from = "noreply@familypeace247.org"; //enter your email address
            $to = $rows['pay_user']; //enter the email address of the contact your sending to
            $subject = "Form Payment For FEPFL Marraiage Academy"; // subject of your email

            $headers = array('From' => $from, 'To' => $to, 'Subject' => $subject);

            $text = ''; // text versions of email.
            $html = '<html><head><style type="text/css"></style></head><body>
<div style="width:410px;background-color:#09a0da; margin:auto;color:white;">
<center><br><img src="' . $url . 'images/logos/it_logo.png" style="width:130px;"></center>
<p style="padding:10px;text-align: center;">SPOTTABLE BOOK STORE</p></div>
<div style="width:410px;margin:auto;">
<p style="padding:10px;text-align: center;font-weight: bold;">Dear  ' . get_fname($rows['pay_user']) . ',</p>
<p style="padding:10px;">Your School payment of <del>N</del>' . $rows['price'] . ', for ' . cert_type($row['mode']) . ' was successful from FEPFL Marriage Academy <br><br>
Kindly Login to your student portal to fill in your information.</p>

<p style="padding:10px;font-weight: bold;"><br><br/> Best Regards, <br><br> Accounts Unit <br> FEPFL Marriage Academy.</p>
<p style="padding:10px;font-style: italic;margin-top: 30px;border-top: 1px solid #09a0da">This email was automatically generated, please do not reply. Kindly send your enquires to fepflmarriageacademy@gmail.com
<br>' . date('l d M,Y', time()) . '</p></div></body></html>';

            $crlf = "\n";

            $file_name = $book_location;
            //echo 'File name is '. $file_name;

            $mime = new Mail_mime($crlf);
            $mime->setTXTBody($text);
            $mime->setHTMLBody($html);
            //  $mime->addAttachment($file_name);
            //do not ever try to call these lines in reverse order
            $body = $mime->get();
            $headers = $mime->headers($headers);

            $host = "localhost"; // your mail server i.e mail.mydomain.com
            $username = "noreply@familypeace247.org"; //  your email address (same as webmail username)
            $password = "NOreply01.,"; // your password (same as webmail password)

            $smtp = Mail::factory('smtp', array(
              'host' => $host, 'auth' => true,
              'username' => $username, 'password' => $password
            ));

            $mail = $smtp->send($to, $headers, $body);

            if (PEAR::isError($mail)) {
              echo ("<p>" . $mail->getMessage() . "</p>");
            } else {
              //echo("<p>Message successfully sent!</p>");
              // header("Location: http://www.example.com/");
              $_SESSION['ref'] = $_GET['reference'];

              $_SESSION['std_email'] = $rows['pay_user'];
              header('location:index');
            }
          } else {
            //faile Transactions
            $_SESSION['status'] = 0;

            header('location:failure');
          }
        }
      } else {
        echo $result['message'];
      }
    }
  }
}
