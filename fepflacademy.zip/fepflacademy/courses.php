<?php ob_start();
session_start();
require('db/config.php');
require('db/functions.php');
if (isset($_SESSION['std_email'])) {
 $std = get_stud_details($_SESSION['std_email']);
 extract($std);
 $pd = get_pay_detail($_SESSION['std_email']);
 extract($pd);

 //error_reporting(0);
} else {
 header("location:login");
}
$link = 2;
?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <meta http-equiv="Content-Language" content="en" />
 <meta name="msapplication-TileColor" content="#2d89ef">
 <meta name="theme-color" content="#4188c9">
 <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
 <meta name="apple-mobile-web-app-capable" content="yes">
 <meta name="mobile-web-app-capable" content="yes">
 <meta name="HandheldFriendly" content="True">
 <meta name="MobileOptimized" content="320">
 <link rel="icon" href="./favicon.ico" type="image/x-icon" />
 <link rel="shortcut icon" type="image/x-icon" href="./favicon.ico" />
 <!-- Generated: 2018-04-06 16:27:42 +0200 -->
 <title>Courses - FEPFL Marraiage Academy</title>
 <?php include('link.php'); ?>

</head>

<body class="">
 <div class="page">
  <div class="page-main">
   <?php include('header.php'); ?>

   <div class="my-3 my-md-5">
    <div class="container">

     <?php if (try_pay($_SESSION['std_email']) > 0 && pay_stat($_SESSION['std_email']) > 0 && form_fill($_SESSION['std_email']) > 0) {
      $pd = get_pay_detail($_SESSION['std_email']);
      extract($pd); ?>
      <div class="row page-header">
       <div class="col-md-12 text-center">
        <h1 class="text-center" style="text-align:center">
         Welcome, <?php echo $std['std_fname']; ?> to FEPFL Marriage Academy
        </h1>
        <div class="col-md-12 text-center">
         <h4 style="text-align: center;">Application Details <br><br>Certificate Type: <b style="color:red"><?php echo cert_type($pd['mode']); ?></b> &nbsp;&nbsp; Study Mode: <b style="color:red"><?php echo get_study_mode($pd['mode']); ?></b> &nbsp;&nbsp; Student Type: <b style="color:red"><?php echo student_type($pd['mode']); ?> &nbsp; &nbsp;</b></h4>
        </div>
        <h3>Your Courses </h3>
       </div>
      </div>
      <div class="row">
       <?php //echo $crl = ($pd['mode']);
       foreach (QueryDB("SELECT * FROM rstudents where std_email='" . $_SESSION['std_email'] . "' ") as $row) {
        extract($row); ?>
        <div class="col-md-12 col-xl-12">
         <div class="card card-collapsed">
          <div class="card-header">
           <div class="card-status card-status-left bg-blue"></div>
           <h3 class="card-title"><a href="#"><b style="color:blue"><?php echo cert_type($std_level); ?> Courses</b></a></h3>
           <div class="card-options">
            <a class="btn btn-pill btn-primary btn-sm text-white">In Progress</a>
            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-circle-down"></i></a>
            <!-- <a href="#" class="card-options-remove" data-toggle="card-remove"><i class="fe fe-x"></i></a> -->
           </div>
          </div>
          <div class="card-body">
           <div class="row">
            <?php //echo $std_level;
            $crcl = cr_lev($std_level);

            //  echo ("SELECT * FROM courses where cr_level='$crcl' ");
            foreach (QueryDB("SELECT * FROM courses where cr_level='$crcl' ") as $crc) {
             extract($crc); ?>
             <div class="col-4 col-md-3 col-sm-3">
              <div class="card">
               <div class="card-status bg-green"></div>
               <div class="card-body text-center">
                <div class="card-category"><?php if ($crcl == $cr_level) {
                                            echo $cr_name;
                                           }

                                           ?></div>
                <div class="display-4" style="font-size:;"><?php echo $cr_code; ?></div>
                <ul class="list-unstyled leading-loose">
                 <li><strong>10</strong> <?php //echo first_row($std_id, $cr_level); //cr_comp($std_id, $cr_code) // $id; //test_score($std_id, get_prev_lesson_code($id, $cr_level)) //get_prev_lesson_code($id, $cr_level); //$id; //get_prev_test_stat($id, $cr_level, $cr_code) 
                                         ?></li>
                 <li><i class="fe fe-check text-success mr-2" aria-hidden="true"></i> Sharing Tools</li>
                 <li><i class="fe fe-check text-success mr-2" aria-hidden="true"></i> Design Tools</li>
                 <li><i class="fe fe-x text-danger mr-2" aria-hidden="true"></i> Private Messages</li>
                 <li><i class="fe fe-x text-danger mr-2" aria-hidden="true"></i> Twitter API</li>
                </ul>
                <div class="text-center mt-6">

                 <a href="study/<?php echo $cr_link; ?>#<?php echo $cr_link; ?>" class="btn btn-blue btn-block">Take Lesson</a>

                 <?php if (cr_comp($std_id, $cr_code) > 0 && test_score($std_id, $cr_code) > 0 && test_score($std_id, $cr_code) < 5) { ?>
                  <a href="study/<?php echo $cr_link; ?>#<?php echo $cr_link; ?>" class="btn btn-yellow btn-block">Retake Test</a>
                 <?php } else { ?>

                  <a href="study/<?php echo $cr_link; ?>#<?php echo $cr_link; ?>" class="btn btn-red btn-block">Take Test</a>
                 <?php } ?>






                </div>
               </div>
              </div>
             </div>
            <?php } ?>
           </div>
          </div>

         </div>
        </div>
       <?php } ?>





      <?php } ?>
      </div>
    </div>
   </div>
  </div>

  <footer class="footer">
   <div class="container">
    <div class="row align-items-center ">
     <div class="col-12 col-lg-auto mt-3 mt-lg-0">
      <p class="text-center">Copyright &copy; <?php echo date('Y'); ?> <a href="https://familypeace247.org">FEPFL Marriage Academy</a></p>
     </div>
    </div>
   </div>
  </footer>
 </div>
 <?php include('scripts.php'); ?>
 <?php include('modals.php'); ?>
</body>

</html>