<?php ob_start();
session_start();
require('db/config.php');
require('db/functions.php');

?>

<!doctype html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta http-equiv="Content-Language" content="en" />
  <meta name="msapplication-TileColor" content="#2d89ef">
  <meta name="theme-color" content="#4188c9">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="HandheldFriendly" content="True">
  <meta name="MobileOptimized" content="320">
  <link rel="icon" href="favicon.ico" type="image/x-icon" />
  <link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
  <!-- Generated: 2018-04-06 16:27:42 +0200 -->
  <title>Login - FEPFL Marriage Academy</title>
  <?php include('link.php'); ?>
</head>

<body class="">
  <div class="page">
    <div class="page-single">
      <div class="container">
        <div class="row">
          <div class="col col-login mx-auto">
            <div class="text-center mb-6">
              <img src="assets/brand/tabler.svg" class="h-6" alt="">
            </div>
            <form class="card" action="" method="POST">
              <?php if (isset($_POST['login'])) {
                $email = $_POST['email'];
                $pass = $_POST['pass'];

                if (QueryDB("SELECT COUNT(*) FROM students where std_email = '$email' and std_pass='$pass' ")->fetchColumn() > 0) {

                  $_SESSION['std_email'] = $email;
                  echo  '<div class="alert alert-success alert-dismissible col-md-12 text-center" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span></button> <strong class="text-italic" style="color:black;">
                                Logging in-Please Wait.. <i class="fa fa-spinner fa-spin"></i>
                                </div>';
                  //$head = "<script>window.history.go(-2);</script>";
                  header('refresh:3; url=index.php');
                  die();

                  // print "<script>swal({text:'Login Successful',type:'success', title:'Successful'}, function(){ window.location = 'index'});</script>";
                } else {
                  $message = '<div class="alert alert-danger alert-dismissible col-md-12 text-center" role="alert">
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span></button> <strong class="text-italic" style="color:black;">
                              Invalid Login Credentials.
                              </div>';
                  //  print "<script>swal({text:'Invalid Login',type:'warning', title:'Error Occured'}, function(){ window.location = ''});</script>";
                }
              } ?>
              <div class="card-body p-6">
                <div class="card-title">Login to your account</div>
                <div class="form-group">
                  <label class="form-label">Email address</label>
                  <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                </div>
                <div class="form-group">
                  <label class="form-label">
                    Password
                    <a href="forgot-password" class="float-right small">I forgot password</a>
                  </label>
                  <input type="password" name="pass" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>
                <div class="form-group">
                  <label class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" />
                    <span class="custom-control-label">Remember me</span>
                  </label>
                </div>
                <div class="form-footer">
                  <input type="submit" name="login" value="Sign in" class="btn btn-primary btn-block">
                </div>
              </div>
            </form>
            <div class="text-center text-muted">
              Don't have account yet? <a href="register">Sign up</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php include('scripts.php'); ?>
  <?php include('modals.php'); ?>

</body>

</html>