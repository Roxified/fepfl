<?php
// $date = date('D, dS F Y @ H:i:s A');
function QueryDB($query)
{
  global $db;
  return $db->query($query);
}

//Reduce Length of Description to 180 only.
function _duration($text)
{
  if (strlen($text) > 200) {
    $returnText = substr($text, 0, 200) . '...';
  } else {
    $returnText = $text;
  }
  return $returnText;
}

function delimiter($string, $limit = 60, $break = ".", $pad = "")
{
  // return with no change if string is shorter than $limit
  if (strlen($string) <= $limit) return $string;

  // is $break present between $limit and the end of the string?
  if (false !== ($breakpoint = strpos($string, $break, $limit))) {
    if ($breakpoint < strlen($string) - 1) {
      //$img = "<center><img src='gmp_online.jpg' class='col-md-9 col-12' style='margin:auto;width:400px;'></center>";
      $string = substr($string, 0, $breakpoint) . '.';
    }
  }
  //$myarray = array($string,$breakpoint);
  return $string;
  //return $myarray;
}

//Check if the field was Empty
function emptyResponse($field, $error)
{
  if (empty($_POST[$field])) {
    return $error;
  }
}

function get_code()
{

  global $conn;

  $alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  $shuffled = str_shuffle($alphabets);

  $serials = substr($shuffled, 0, 5) . rand(100, 999);

  return $serials;
}

function validate($value)
{
  $value = trim($value);
  $value = stripslashes($value);
  $value = htmlspecialchars($value);
  $value = str_replace('"', '&quot;', $value);
  $value = str_replace("'", '&apos;', $value);
  return $value;
}

function code_pics($count)
{
  $alphabets = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $rCode = rand(10, 99);
  $class_unique = rand(10, 99) . substr(str_shuffle($alphabets), 0, $count) . $rCode;
  return $class_unique;
}

function watermarkImage($SourceFile, $WaterMarkText, $DestinationFile)
{
  list($width, $height) = getimagesize($SourceFile);
  $image_p = imagecreatetruecolor($width, $height);
  $image = imagecreatefromjpeg($SourceFile);
  imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width, $height);
  $black = imagecolorallocate($image_p, 224, 224, 224);
  $font = 'arial.ttf';
  $font_size = 19;
  imagettftext($image_p, $font_size, 0, 38, 38, $black, $font, $WaterMarkText);
  if ($DestinationFile <> '') {
    imagejpeg($image_p, $DestinationFile, 100);
  } else {
    header('Content-Type: image/jpeg');
    imagejpeg($image_p, null, 100);
  };
  imagedestroy($image);
  imagedestroy($image_p);
};


function appleWater($image_name)
{
  $SourceFile = $image_name;
  $DestinationFile = $image_name;
  $WaterMarkText = 'BE';
  return watermarkImage($SourceFile, $WaterMarkText, $DestinationFile);
}


// function _greetin(){

//   date_default_timezone_set('Africa/lagos');

// // 24-hour format of an hour without leading zeros (0 through 23)
//   $Hour = date('G');

//   if ( $Hour >= 1 && $Hour <= 11 ) {

//     $salute = 'Bonjour   ';
//   } else if ( $Hour >= 12 && $Hour <= 16 ) {

//     $salute = 'Bon apres-midi ';
//   } else if ( $Hour >= 17 || $Hour <= 22 ) {

//     $salute = 'Bonsoir ';
//   }
//   else if ( $Hour >= 23 || $Hour <= 24 ) {

//     $salute = 'Keeping Late Night?   ';
//   }
//   return $salute;
// }

function _greetin()
{



  date_default_timezone_set('Africa/lagos');



  // 24-hour format of an hour without leading zeros (0 through 23)

  $Hour = date('G');
  if ($Hour >= 1 && $Hour <= 11) {
    $salute = 'Good Morning   ';
  } else if ($Hour >= 12 && $Hour <= 16) {
    $salute = 'Good Afternoon  ';
  } else if ($Hour >= 17 || $Hour <= 22) {
    $salute = 'Good Evening   ';
  } else if ($Hour >= 23 || $Hour <= 24) {
    $salute = 'Keeping Late Night?   ';
  }

  return $salute;
}

function get_time_ago($time)

{

  $time_difference = time() - $time;

  if ($time_difference < 1) {
    return 'less than 1 second ago';
  }

  $condition = array(
    12 * 30 * 24 * 60 * 60 =>  'year',

    30 * 24 * 60 * 60       =>  'month',

    24 * 60 * 60            =>  'day',

    60 * 60                 =>  'hour',

    60                      =>  'minute',

    1                       =>  'second'

  );



  foreach ($condition as $secs => $str) {

    $d = $time_difference / $secs;



    if ($d >= 1) {

      $t = round($d);

      return $t . ' ' . $str . ($t > 1 ? 's' : '') . ' ago';
    }
  }
}

function get_event_details()
{
  return QueryDB("SELECT * FROM events ");
}

function get_admin_info($username)
{
  $start = QueryDB("SELECT * FROM admin WHERE username ='$username'");
  return $row = $start->fetch(PDO::FETCH_ASSOC);
}


function poster($code)
{
  $get = QueryDB("SELECT admin_name from admin where admin_id = '$code' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['admin_name'];
}

//////////FEPFL ACADEMY STUDENTS//////////////

function get_fname($email)
{
  $start = QueryDB("SELECT std_fname FROM students WHERE std_email ='$email'");
  $row = $start->fetch(PDO::FETCH_ASSOC);
  return $row['std_fname'];
}

function get_stud_info($email)
{
  $start = QueryDB("SELECT * FROM users WHERE email ='$email'");
  return $row = $start->fetch(PDO::FETCH_ASSOC);
}

function get_stud_details($email)
{
  $start = QueryDB("SELECT * FROM students WHERE std_email ='$email'");
  $row = $start->fetch(PDO::FETCH_ASSOC);
  return $row;
}

function get_rstud_details($email, $level)
{
  $start = QueryDB("SELECT * FROM rstudents WHERE std_email ='$email' and std_level='$level' ");
  $row = $start->fetch(PDO::FETCH_ASSOC);
  return $row;
}
function current_level($email)
{
  $start = QueryDB("SELECT mode FROM fpay WHERE pay_user ='$email' order by id DESC LIMIT 1");
  $row = $start->fetch(PDO::FETCH_ASSOC);
  return $row['mode'];
}

function get_pay_detail($email)
{
  $start = QueryDB("SELECT * FROM fpay WHERE pay_user ='$email' order by id DESC LIMIT 1");
  $row = $start->fetch(PDO::FETCH_ASSOC);
  return $row;
}
function get_prog_det($user_id)
{
  $start = QueryDB("SELECT * FROM programme WHERE std_id ='$user_id'");
  $row = $start->fetch(PDO::FETCH_ASSOC);
  return $row;
}

function get_price_by_id($code)
{
  $get = QueryDB("SELECT prog_form from prog where prog_id='$code'  ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['prog_form'];
}

function student_type($mode)
{
  if ($mode == 'FULLS') {
    $msg = 'Single';
  } else   if ($mode == 'FULLC') {
    $msg = 'Couple';
  } else   if ($mode == 'LEV1S') {
    $msg = 'Single';
  } else   if ($mode == 'LEV2S') {
    $msg = 'Single';
  } else   if ($mode == 'YTHMS') {
    $msg = 'Single';
  } else   if ($mode == 'DIPLS') {
    $msg = 'Single';
  } else   if ($mode == 'LEV1C') {
    $msg = 'Couple';
  } else   if ($mode == 'LEV2C') {
    $msg = 'Couple';
  } else   if ($mode == 'YTHMC') {
    $msg = 'Couple';
  } else   if ($mode == 'DIPLC') {
    $msg = 'Couple';
  }

  return $msg;
}

function cr_lev($mode)
{
  if ($mode == 'FULLS') {
    $msg = 'FULL';
  } else   if ($mode == 'FULLC') {
    $msg = 'FULL';
  } else   if ($mode == 'LEV1S') {
    $msg = 'LEV1';
  } else   if ($mode == 'LEV2S') {
    $msg = 'LEV2';
  } else   if ($mode == 'YTHMS') {
    $msg = 'LEV3';
  } else   if ($mode == 'DIPLS') {
    $msg = 'LEV4';
  } else   if ($mode == 'LEV1C') {
    $msg = 'LEV1';
  } else   if ($mode == 'LEV2C') {
    $msg = 'LEV2';
  } else   if ($mode == 'YTHMC') {
    $msg = 'LEV3';
  } else   if ($mode == 'DIPLC') {
    $msg = 'LEV4';
  }

  return $msg;
}

function cr_comp($id, $cr_id)
{
  return  QueryDB("SELECT COUNT(*) FROM topics where std_id='$id' and cr_id='$cr_id' ")->fetchColumn();
}

function test_comp($id, $cr_id)
{
  return  QueryDB("SELECT COUNT(*) FROM topics where std_id='$id' and cr_id='$cr_id' ")->fetchColumn();
}

function test_score($id, $cr_id)
{
  $get =   QueryDB("SELECT tp_test FROM topics where std_id='$id' and cr_id='$cr_id' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['tp_test'];
}

function first_course($cr_id)
{
  $get = QueryDB("SELECT * FROM courses where cr_level='$cr_id' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['cr_code'];
}

function first_row($id, $cr_lev)
{
  $get = QueryDB("SELECT * FROM topics where std_id = '$id' and cr_lev='$cr_lev' ");

  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['cr_id'];
}

function rcr_lev($mode, $type)
{
  if ($mode == 'LEV5' && $type == 'Single') {
    $msg = 'FULLS';
  } else   if ($mode == 'LEV5' && $type == 'Couple') {
    $msg = 'FULLC';
  } else   if ($mode == 'LEV1' && $type == 'Single') {
    $msg = 'LEV1S';
  } else   if ($mode == 'LEV2' && $type == 'Single') {
    $msg = 'LEV2S';
  } else   if ($mode == 'LEV3' && $type == 'Single') {
    $msg = 'YTHMS';
  } else   if ($mode == 'LEV4' && $type == 'Single') {
    $msg = 'DIPLS';
  } else   if ($mode == 'LEV1' && $type == 'Couple') {
    $msg = 'LEV1C';
  } else   if ($mode == 'LEV2' && $type == 'Couple') {
    $msg = 'LEV2C';
  } else   if ($mode == 'LEV3' && $type == 'Couple') {
    $msg = 'YTHMC';
  } else   if ($mode == 'LEV4' && $type == 'Couple') {
    $msg = 'DIPLC';
  }

  return $msg;
}

function cert_type($mode)
{
  $get = QueryDB("SELECT prog_name FROM prog where prog_id='$mode' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['prog_name'];
}

function get_study_mode($code)
{
  if (substr($code, 0, 4) == 'FULL') {
    $msg = 'Full Time';
  } else {
    $msg = 'Batch Mode';
  }
  return $msg;
}

function prog_code($code)
{
  $get = QueryDB("SELECT prog_name from prog where prog_id='$code'  ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['prog_name'];
}
function get_stud_email($user_id)
{
  $get = QueryDB("SELECT email FROM users WHERE code = '$user_id' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['email'];
}

function get_stud_code($email)
{
  $get = QueryDB("SELECT * FROM users WHERE email = '$email' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['code'];
}
function get_stud_form_fill($ucode)
{
  $get = QueryDB("SELECT status FROM details WHERE user_id = '$ucode' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['status'];
}

function pay_stat($user)
{
  return QueryDB("SELECT COUNT(*) FROM fpay where pay_user='$user' and pay_status='Approved' and confirm_time!=''  ")->fetchColumn();
}

function prev_pay($id, $user, $mode, $price)
{
  return QueryDB("SELECT COUNT(*) FROM fpay where pay_id='$id' and pay_user='$user' and mode='$mode'  and price='$price'  ")->fetchColumn();
}

function try_pay($user)
{
  return QueryDB("SELECT COUNT(*) FROM fpay where pay_user='$user'  ")->fetchColumn();
}

function form_fill($user)
{
  return QueryDB("SELECT COUNT(*) FROM students where std_email='$user' and std_sex!='' and std_phone!='' and std_age!='' ")->fetchColumn();
}

function get_last_num()
{
  $get = QueryDB("SELECT id FROM students  ORDER BY id DESC LIMIT 1  ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  $docket = $getter['id'] + 1;
  if (strlen($docket) == 1) {
    $msg = '00' . $docket;
  } elseif (strlen($docket) == 2) {
    $msg = '0' . $docket;
  }
  return 'FEPFL/' . date('Y') . '/' . $msg;
}

function get_prev_id($id, $lev)
{
  return QueryDB("SELECT COUNT(id) FROM courses where id = (select max(id) from courses where id<'$id' and cr_level='$lev') ORDER BY id DESC LIMIT 1  ")->fetchColumn();
  // $getter = $get->fetch(PDO::FETCH_ASSOC);
  // $docket = $getter['id'];
  // if (($docket) < 1) {
  //   $msg = 0;
  // } elseif (($docket) > 0) {
  //   $msg = 1;
  // }
  // return $msg;
}

function get_prev_lesson($id, $lev)
{
  $get = QueryDB("SELECT cr_link FROM courses where id = (select max(id) from courses where id<'$id' and cr_level='$lev')  ORDER BY id DESC LIMIT 1  ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  $docket = $getter['cr_link'];

  return $docket;
}

function get_last_lesson($id)
{
  $get = QueryDB("SELECT cr_id FROM topics where std_id= '$id'  ORDER BY id DESC LIMIT 1  ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  $docket = $getter['cr_id'];

  return $docket;
}

function laster($id)
{
  $get = QueryDB("SELECT id FROM courses where cr_code= '$id'  ORDER BY id DESC LIMIT 1  ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  $docket = $getter['id'];

  return $docket;
}

function get_next_lesson($id, $lev)
{
  $get = QueryDB("SELECT cr_link FROM courses where id = (select min(id) from courses where id>'$id' and cr_level='$lev')  ORDER BY id ASC LIMIT 1  ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  $docket = $getter['cr_link'];

  return $docket;
}

function get_first_lesson($lev)
{
  $get = QueryDB("SELECT * FROM courses where cr_level='$lev'  ORDER BY id ASC LIMIT 1  ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  $docket = $getter['cr_link'];

  return $docket;
}

function get_prev_lesson_code($id, $lev)
{
  $get = QueryDB("SELECT cr_code FROM courses where id = (select max(id) from courses where id<'$id' and cr_level='$lev')  ORDER BY id DESC LIMIT 1  ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  $docket = $getter['cr_code'];

  return $docket;
}

// function get_prev_test_stat($id, $lev, $cr_id)
// {
//   $get = QueryDB("SELECT tp_test FROM topics where id = (select max(id) from topics where id<'$id' and cr_lev='$lev' and cr_id='$cr_id')  ORDER BY id DESC LIMIT 1  ");
//   $getter = $get->fetch(PDO::FETCH_ASSOC);
//   $docket = $getter['tp_test'];

//   return $docket;
// }


////////////////////////////////////////////////



///////////// FUNCTIONS FOR BOOKS//////////////////////


function book_code()
{
  global $conn;

  $serials = rand(1000000, 9999999);

  return $serials;
}

function get_all_books()
{
  return QueryDB("SELECT * FROM books where book_avail=1 ");
}

function get_book_count()
{
  return QueryDB("SELECT COUNT(*) FROM books  ")->fetchColumn();
}

function cat_code()
{
  global $conn;

  $alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  $shuffled = str_shuffle($alphabets);

  $serials = substr($shuffled, 0, 5) . rand(100, 999);

  return $serials;
}

function post_id()
{
  global $conn;
  $code = rand(100000, 999999);
  return $code;
}

function pay_id()
{
  global $conn;
  $code = rand();
  return $code;
}

function get_post_details()
{
  return QueryDB("SELECT * FROM posts ");
}


function get_cat_by_code($code)
{
  $get = QueryDB("SELECT cat_name from category where cat_id ='$code' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['cat_name'];
}

function get_cat_by_name($code)
{
  $get = QueryDB("SELECT cat_id from category where cat_name ='$code' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['cat_id'];
}

function get_cat()
{
  return QueryDB("SELECT * FROM category where cat_status=0 ");
}

function post_cat_counter($code)
{
  return  QueryDB("SELECT COUNT(*) FROM  posts where post_cat ='$code' ")->fetchColumn();
}

function get_book_details()
{
  return QueryDB("SELECT * from books ");
}



function get_cat_details()
{
  return QueryDB("SELECT * from category ");
}

function get_spef_book($code)
{
  $get = QueryDB("SELECT * FROM books where book_id ='$code' ");
  return $get->fetch(PDO::FETCH_ASSOC);
}

function bookCount()
{
  return QueryDB("SELECT COUNT(*) from books ")->fetchColumn();
}

/////////////////////////////////////////////////////


//NORMAL USERS LOGGEN IN ON THE PORTAL//

function get_user_details($email)
{
  $get = QueryDB("SELECT * FROM f_users WHERE email = '$email' ");
  return $get->fetch(PDO::FETCH_ASSOC);
}

function get_book_path($ref)
{
  $get = QueryDB("SELECT item_location from payment where pay_ref ='$ref' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['item_location'];
}

function get_user_name($email)
{
  $get = QueryDB("SELECT fname from f_users where email ='$email' ");
  $getter = $get->fetch(PDO::FETCH_ASSOC);
  return $getter['fname'];
}





////////////////////////////////////////////

/////FEPFL ADMIN ////////

function get_all_stud()
{
  return QueryDB("SELECT COUNT(*) from users ")->fetchColumn();
}

function get_all_post()
{
  return QueryDB("SELECT COUNT(*) from posts ")->fetchColumn();
}

function get_all_events()
{
  return QueryDB("SELECT COUNT(*) from events ")->fetchColumn();
}

function get_all_cat()
{
  return QueryDB("SELECT COUNT(*) from category ")->fetchColumn();
}

function get_all_paid_book()
{
  return QueryDB("SELECT COUNT(*) from payment where pay_status ='Approved' ")->fetchColumn();
}

function get_all_students()
{
  return QueryDB("SELECT * from details ");
}

function get_f_users()
{
  return QueryDB("SELECT * FROM f_users ");
}

function get_all_f_users()
{
  return QueryDB("SELECT COUNT(*) FROM f_users ")->fetchColumn();
}
///////////////////////////////////////


//RESIZE IMAGE CODELINE**/
function makeThumbnail($sourcefile, $max_width, $max_height, $endfile, $type)
{
  switch ($type) {
    case 'image/png':
      $img  = imagecreatefrompng($sourcefile);
      break;
    case 'image/jpeg':
      $img   = imagecreatefromjpeg($sourcefile);
      break;
    case 'image/gif':
      $img  = imagecreatefromgif($sourcefile);
      break;
    case 'image/jpg':
      $img  = imagecreatefromjpg($sourcefile);
      break;
    case 'image/JPG':
      $img  = imagecreatefromjpg($sourcefile);
      break;
    case 'image/gif':
      $img  = imagecreatefromgif($sourcefile);
      break;
    default:
      return 'Unsupported format';
  }
  $width = imagesx($img);
  $height = imagesy($img);
  if ($width > $height) {
    if ($width < $max_width) $newwidth = $width;
    else $newwidth = $max_width;
    $divisor = $width / $newwidth;
    $newheight = floor($height / $divisor);
  } else {
    if ($height < $max_height) $newheight = $height;
    else $newheight =  $max_height;
    $divisor = $height / $newheight;
    $newwidth = floor($width / $divisor);
  }
  $tmpimg = imagecreatetruecolor($newwidth, $newheight);
  imagealphablending($tmpimg, false);
  imagesavealpha($tmpimg, true);
  imagecopyresampled($tmpimg, $img, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
  switch ($type) {
    case 'image/png':
      imagepng($tmpimg, $endfile, 0);
      break;
    case 'image/jpeg':
      imagejpeg($tmpimg, $endfile, 100);
      break;
    case 'image/jpg':
      imagejpg($tmpimg, $endfile, 100);
      break;
    case 'image/JPG':
      imageJPG($tmpimg, $endfile, 100);
      break;
    case 'image/gif':
      imagegif($tmpimg, $endfile, 0);
      break;
  }
  imagedestroy($tmpimg);
  imagedestroy($img);
}


function remove_dash($val)
{
  return str_replace("-", " ", $val);
}

function cat_to_name($cat_code)
{
  $st = QueryDB("SELECT cat_title FROM category WHERE  cat_code ='$cat_code'  ");
  $row = $st->fetch(PDO::FETCH_ASSOC);
  return $row['cat_title'];
}

function sub_code_to_name($cat_code)
{
  $st = QueryDB("SELECT subname FROM subcat WHERE  id ='$cat_code'  ");
  $row = $st->fetch(PDO::FETCH_ASSOC);
  return $row['subname'];
}

function cat_name_to_code($cat_name)
{
  $st = QueryDB("SELECT cat_code FROM category WHERE  cat_title ='$cat_name'  ");
  $row = $st->fetch(PDO::FETCH_ASSOC);
  return $row['cat_code'];
}

function sub_name_to_code($cat_name_sub)
{
  $st = QueryDB("SELECT id FROM subcat WHERE  subname ='$cat_name_sub'  ");
  $row = $st->fetch(PDO::FETCH_ASSOC);
  return $row['id'];
}


function get_product_without_pid($details)
{
  $get_next_pid = strpos($details, substr($details, -9, 9));
  return substr($details, 0, $get_next_pid);
}

function get_pid($value)
{
  return substr($value, -8, 8);
}

function get_specs($pid)
{
  $start = QueryDB("SELECT * FROM products WHERE pid ='$pid' ");
  return $start->fetch(PDO::FETCH_ASSOC);
}


function reviewTotal($pid)
{
  return QueryDB("SELECT COUNT(*) FROM product_reviews WHERE product_pid ='$pid' ")->fetchColumn();
}



function get_size_value($val)
{
  switch ($val) {
    case 1:
      return 'xs-size';
      break;
    case 2:
      return 's-size';
      break;
    case 3:
      return 'm-size';
      break;
    case 4:
      return 'l-size';
      break;
    case 5:
      return 'xl-size';
      break;
    case 6:
      return 'xxl-size';
      break;
    default:
      break;
  }
}

function get_size_string($val)
{
  $msg = '';
  if ($val == 'XS') {
    $msg = 'Extra Small';
  } elseif ($val == 'S') {
    $msg = 'Small';
  } elseif ($val == 'M') {
    $msg = 'Medium';
  } elseif ($val == 'L') {
    $msg = 'Large';
  } elseif ($val == 'XL') {
    $msg = 'Extra Large';
  } elseif ($val == 'XXL') {
    $msg = 'Extra Extra Large';
  }
  return $msg;
}



function get_actual_amt($discount, $price)
{
  $amt = 0;
  if ($discount == 0) {
    $amt = $price;
  } else {
    $amt_started = ($price * $discount / 100);
    $amt = ($price - $amt_started);
  }
  return $amt;
}


function calculate_discount($discount, $price)
{
  if ($discount == 0) {
    $dis = 0;
  } else {
    $dis = ($price * $discount / 100);
  }
  return $dis;
}

function get_total_items($email)
{
  $startCount = 0;
  foreach (QueryDB("SELECT * FROM cart where type='cart' and pro_buyer='" . $email . "' ") as $rows) {
    $startCount += $rows['quan'];
  }
  return $startCount;
}

function get_total_amount($email)
{
  $total_cost = 0;
  foreach (QueryDB("SELECT * FROM cart where type='cart' and pro_buyer='" . $email . "' ") as $rows) {
    $total_cost += $rows['item_cost'];
  }
  return $total_cost;
}

function getCoupon($coupon)
{
  $start = QueryDB("SELECT * FROM coupons WHERE coupon='$coupon' ");
  return $start->fetch(PDO::FETCH_ASSOC);
}


function get_billing($bill_user)
{
  $start = QueryDB("SELECT * FROM billing WHERE bill_user='$bill_user' ");
  return $start->fetch(PDO::FETCH_ASSOC);
}

function remove_comma($val)
{
  return str_replace(",", "", $val);
}
