<?php

//$conn = new mysqli('localhost', 'root', '', 'fepfl');

try {
 $db = new PDO('mysql:host=localhost;dbname=fepfl;charset=utf8', 'root', '');
} catch (Expression $e) {
 echo $e->getMessage();
}

//$referer = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : '';
