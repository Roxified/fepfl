<?php
ob_start();
session_start();
require 'db/config.php';
require 'db/functions.php';
// if(!isset($_SESSION['user_acct'])){ header('location:index.php');}

if (isset($_SESSION['std_email'])) {
} else {
  header("location:login");
}

$user = $_SESSION['std_email'];
$id = $_GET['pay_id'];
$price = $_GET['price'];
$ref = $_GET['ref'];
$mode = $_GET['mode'];
$type = $_GET['type'];

//if($_GET['type']=='Full' && $_GET['mode'])
if (prev_pay($id, $user, $mode, $type, $price) > 0) {
  if (QueryDB("UPDATE fpay SET  pay_time='" . time() . "', pay_status='pending' where pay_id='$id' and pay_user='$user' and sem=5 ")) {
    header('location:formPayment');
    //print "<script>alert('Worked');</script>";
  } else {
    print "<script>alert('Repayment Failed'); windows.location='index'</script>";
  }
} else {
  if (QueryDB("INSERT INTO fpay (pay_id, pay_ref, pay_time, price	, pay_user	, pay_status	, confirm_time	, mode	, others, sem	) VALUES('" . $_GET['pay_id'] . "','" . $_GET['ref'] . "','" . time() . "',
'" . $_GET['price'] . "','" . $_SESSION['std_email'] . "','pending',0,'" . $_GET['mode'] . "',0,5 ) ") && QueryDB("INSERT INTO ")) {
    header('location:formPayment');
  } else {
    print "<script>alert('Transaction Failed'); windows.location='index'</script>";
  }
}


if (isset($_GET['payer'])) {
  $payer = $_GET['payer'];
  $pay_id = $_GET['pay_id'];
  $amt = $_GET['amt'];
  $pay_mode = $_GET['pay_mode'];

  if (QueryDB("SELECT * FROM schpay where pay_user='$payer' and mode='$pay_mode' and price='$amt' ")->fetchColumn() > 0) {

    if (QueryDB("INSERT INTO schpay (pay_id, pay_ref, pay_time, price	, pay_user	, pay_status	, confirm_time	, mode	, others, sem	) VALUES('$pay_id','$pay_ref','" . time() . "',
'$amt','$payer','pending',0,'$pay_mode',0,0 ) ")) {
      header('location:formPayment');
    } else {
      print "<script>alert('Transaction Failed'); windows.location='payments'</script>";
    }
  }
}
