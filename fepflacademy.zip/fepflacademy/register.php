<?php ob_start();
session_start();
require('db/config.php');
require('db/functions.php');

?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta http-equiv="Content-Language" content="en" />
  <meta name="msapplication-TileColor" content="#2d89ef">
  <meta name="theme-color" content="#4188c9">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="HandheldFriendly" content="True">
  <meta name="MobileOptimized" content="320">
  <link rel="icon" href="favicon.ico" type="image/x-icon" />
  <link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
  <!-- Generated: 2018-04-06 16:27:42 +0200 -->
  <title>Register - tabler.github.io - a responsive, flat and full featured admin template</title>
  <?php include('link.php'); ?>
</head>

<body class="">
  <div class="page">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="panel">
            <div class="panel-header bg-primary text-center text-white ">
              <h1>FEPFL MARRIAGE ACADEMY</h1>
              <h2>Start your application</h2>
              <h5 style="padding: 10px;">Thank you for your interest in applying to FEPFL Marriage Academy. To begin your application
                process, please note that you will be charged a form fee of <del>N</del>1000.00 or $2 <br><br>
                Please fill in the correct informations below !</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="page-single">

      <div class="container">
        <div class="row">
          <div class="col col-login mx-auto">
            <div class="text-center mb-6">
              <img src="assets/brand/tabler.svg" class="h-6" alt="">
            </div>
            <form class="card" action="" method="post">

              <?php if (isset($_POST['create'])) {

                $fname = $_POST['fname'];
                $lname = $_POST['lname'];
                $email = $_POST['email'];
                $pass = $_POST['pass'];
                //  $prog = $_POST['prog'];
                //$std_id = get_last_num();

                //check if user already exist

                if (QueryDB("SELECT COUNT(*) FROM students where std_email ='$email' ")->fetchColumn() > 0) {
                  print "<script>swal({text:'Registration Previously Done',type:'warning', title:'Duplicate Registration'}, function(){ window.location = ''});</script>";
                }


                if (QueryDB("INSERT INTO students (std_id,std_title,	std_fname,	std_oname,	std_lname,	std_pass,	std_sex,	std_age, std_country,	std_state,	std_lga,	std_addr,	std_religion,	std_email,	std_phone,	std_qual,	std_job,	std_jobp,	
                  std_desg,	std_iden,	std_m,	std_mstat,	std_myrs,	std_noc,	std_mtype,	std_mdate,	std_passport,	reg_date,	status) VALUES ('','',	'$fname',	'',	'$lname',	'$pass',	'',	'',	'',	'', '',	'',	'',	'$email',	'',	'',	'',	'',	'', '',	'',	'',	0,	0,	0,	0,	'',	'" . time() . "',	0) "))
                // && QueryDB("INSERT INTO programme (std_id,prog_id,adm_stat,reg_date,adm_date,status) VALUES ('$std_id','$prog',0,'" . time() . "',0,0) ")) 
                {
                  print "<script>swal({text:'Registration Successful',type:'success', title:'Successful'}, function(){ window.location = 'login'});</script>";
                } else {
                  print "<script>swal({text:'Registration Unsuccessful',type:'warning', title:'Error Occured'}, function(){ window.location = ''});</script>";
                }
              }

              ?>
              <div class="card-body p-6">
                <div class="card-title">Create New account</div>
                <div class="form-group">
                  <label class="form-label">First Name</label>
                  <input type="text" name="fname" required class="form-control" placeholder="Enter First Name">
                </div>
                <div class="form-group">
                  <label class="form-label">Last Name</label>
                  <input type="text" name="lname" required class="form-control" placeholder="Enter Last Name">
                </div>
                <div class="form-group">
                  <label class="form-label">Email address</label>
                  <input type="email" name="email" required class="form-control" placeholder="Enter email">
                </div>
                <!-- <div class="form-group">
                  <label class="form-label">Select Study Type</label>
                  <select name="prog" id="prog" class="form-control">
                    <option value="">Select Study type</option>

                    <option value="1">Full-Time Study</option>
                    <option value="2">Batch Study</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label">Select Program to Apply</label>
                  <select name="prog" id="" class="form-control">
                    <option value="">Select Program</option>
                    <?php // foreach (QueryDB("SELECT * FROM prog ") as $pg) { extract($pg); 
                    ?>
                      <option value="<?php // echo $prog_id; 
                                      ?>"><?php // echo $prog_name; 
                                          ?></option> <?php // } 
                                                      ?>
                  </select>
                </div> -->

                <div class="form-group">
                  <label class="form-label">Password</label>
                  <input type="password" name="pass" required class="form-control" placeholder="Password">
                </div>
                <div class="form-group">
                  <label class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" required />
                    <span class="custom-control-label">Agree the <a href="#">terms and policy</a></span>
                  </label>
                </div>
                <div class="form-footer">
                  <input type="submit" name="create" class="btn btn-primary btn-block" value="Create new account">
                </div>
              </div>
            </form>
            <div class="text-center text-muted">
              Already have account? <a href="login">Sign in</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>