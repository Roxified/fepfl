<?php ob_start();
session_start();
require('../db/config.php');
require('../db/functions.php');
if (isset($_SESSION['std_email'])) {
 $std = get_stud_details($_SESSION['std_email']);
 extract($std);
 $pd = get_pay_detail($_SESSION['std_email']);
 extract($pd);
 $rstd = get_rstud_details($_SESSION['std_email'], $mode);
 extract($std);

 $_SESSION['std_id'] = $rstd['std_id'];

 $get_title = $_REQUEST['param'];

 $_SESSION['rep'] = $get_title;
 $find_title = $db->query("SELECT * FROM  courses WHERE cr_link ='" . $_SESSION['rep'] . "'  ");
 $q = $find_title->fetch(PDO::FETCH_ASSOC);
 //echo $q['cr_code'];
 $_SESSION['cr_id'] = $q['cr_code'];
 $_SESSION['cr_lev'] = $q['cr_level'];

 //error_reporting(0);
} else {
 header("location:../login");
}
$link = 2;

if (isset($_POST['comp'])) {
 $cr_id = $_POST['cr_id'];
 $cr_lev = $_POST['cr_lev'];


 if (QueryDB("SELECT COUNT(*) FROM topics where std_id='" . $_SESSION['std_id'] . "' and cr_id='" . $_SESSION['cr_id'] . "' ")->fetchColumn() > 0) {
 } else {

  if (QueryDB("INSERT INTO topics (std_id,	cr_id, cr_lev,	std_email,	tp_test,	tp_exams,	tp_trial,	tp_date,	tp_stat	
) VALUES ('" . $_SESSION['std_id'] . "', '$cr_id','$cr_lev','" . $_SESSION['std_email'] . "','','',0,'" . time() . "',0) ")) {
  }
 }
}
?>

<!doctype html>
<html lang="en" dir="ltr">

<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <meta http-equiv="Content-Language" content="en" />
 <meta name="msapplication-TileColor" content="#2d89ef">
 <meta name="theme-color" content="#4188c9">
 <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
 <meta name="apple-mobile-web-app-capable" content="yes">
 <meta name="mobile-web-app-capable" content="yes">
 <meta name="HandheldFriendly" content="True">
 <meta name="MobileOptimized" content="320">
 <link rel="icon" href="./favicon.ico" type="image/x-icon" />
 <link rel="shortcut icon" type="image/x-icon" href="./favicon.ico" />
 <!-- Generated: 2018-04-06 16:27:42 +0200 -->
 <title><?php echo $q['cr_name']; ?>- FEPFL Marriage Academy</title>
 <?php include('link.php'); ?>
</head>

<body class="">
 <div class="page">
  <div class="page-main">
   <?php include('header.php'); ?>
   <?php // echo test_score($_SESSION['std_id'], $_SESSION['cr_id']); // echo test_score($_SESSION['std_id'], get_prev_lesson_code($q['id'], $q['cr_level'])); 
   ?>
   <div class="my-3 my-md-5">
    <div class="container" id="">
     <h2 class="page-title mb-5 text-center" style="font-weight: bold;"><?php // echo first_course($_SESSION['cr_lev']) 
                                                                        ?><?php echo $q['cr_name'];
                                                                          ?></h2>
     <div class="row">
      <?php if (first_course($_SESSION['cr_lev']) == $_SESSION['cr_id']) { ?>
       <div class="col-md-12">
        <div class="card">
         <div class="card-header">
          <div class="card-title">
           <p class="text-danger">
            <?php //echo $q['cr_level'];
            // echo $pd['mode'];
            //echo student_type($pd['mode']);
            //  echo rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']));
            echo cert_type(rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']))); ?><i class="fe fe-chevron-right"></i> <?php echo '(' . $q['cr_code'] . ') ' . strtok($q['cr_name'], ':'); ?><i class="fe fe-chevron-right"></i> <?php echo ($q['cr_name']); ?></p>
          </div>
         </div>
         <?php //echo $q['id'];
         //echo get_prev_id($q['id'], $q['cr_level']);
         // echo get_prev_lesson_code($q['id'], $q['cr_level']);
         //  echo test_score($_SESSION['std_id'], get_prev_lesson_code($q['id'], $q['cr_level']));
         ?>
         <!-- <h2>This is the first course</h2> -->
         <div class="card-body">
          <figure>
           <iframe src="../../schoolMaster/topics/Marriage Dynamics-FEPFL Marraige Acdemy.pdf" width="100%" height="500px" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen frameborder="0"></iframe>
          </figure>
         </div>

        </div>
        <?php //echo $q['id'];
        // echo get_prev_id($q['id'], $q['cr_level']);
        ?>
        <form action="">
         <div class="btn-list mt-4 ">
          <?php if (get_prev_id($q['id'], $_SESSION['cr_lev']) == 0) {
          } else { ?>
           <a href="../study/<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>#<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>" class="btn btn-secondary btn-space text-left">Previous Lesson</a>
          <?php }  ?>
          <?php if (cr_comp($_SESSION['std_id'], $_SESSION['cr_id']) < 1) { ?>
           <!-- <a class=" ref btn btn-primary btn-space text-right text-white"><i class="fe fe-file"></i> Take Test </a> -->
           <a id="comp" data-id="<?php echo $_SESSION['cr_lev'] ?>" data-id2="<?php echo $_SESSION['cr_id']; ?>" class=" ref btn btn-primary btn-space text-right text-white"><i class="fe fe-check"></i> Mark Complete </a>
          <?php } else { ?>
           <a id="" class=" ref btn btn-primary btn-space text-right text-white text-muted ">Lesson Completed <i class="fe fe-check-circle"></i></a>
           <?php if (test_score($_SESSION['std_id'], $_SESSION['cr_id']) > 0 && test_score($_SESSION['std_id'], $_SESSION['cr_id']) < 5) { ?>
            <a id="" class=" btn btn-success btn-space text-right  text-white"><i class="fe fe-check"></i> Retake Test</a>
           <?php } elseif (empty(test_score($_SESSION['std_id'], $_SESSION['cr_id']))) { ?>
            <a id="" class=" btn btn-success btn-space text-right  text-white"><i class="fe fe-check"></i> Take Test</a>
           <?php } else { ?>
            <a id="" class=" ref btn btn-primary btn-space text-right text-white text-muted ">Test Completed <i class="fe fe-check-circle"></i></a>
            <a id="" class=" ref btn btn-primary btn-space text-right text-white text-muted ">View Score <i class="fe fe-check-circle"></i></a>

            <a href="../study/<?php echo get_next_lesson($q['id'], $_SESSION['cr_lev']); ?>#<?php echo get_next_lesson($q['id'], $_SESSION['cr_lev']); ?>" id="" class=" ref btn btn-info btn-space text-right text-white text-muted ">Next Lesson </a>

          <?php }
          } ?>
         </div>
        </form>
       </div>
      <?php } else { ?>
       <?php if (cr_comp($_SESSION['std_id'], $_SESSION['cr_id']) > 0 &&  test_score($_SESSION['std_id'], get_prev_lesson_code($q['id'], $q['cr_level']))  < 5) { ?>
        <div class="col-md-12">
         <div class="card">
          <div class="card-header">
           <div class="card-title">
            <p class="text-danger">
             <?php //echo $q['cr_level'];
             // echo $pd['mode'];
             //echo student_type($pd['mode']);
             //  echo rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']));
             echo cert_type(rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']))); ?><i class="fe fe-chevron-right"></i> <?php echo '(' . $q['cr_code'] . ') ' . strtok($q['cr_name'], ':'); ?><i class="fe fe-chevron-right"></i> <?php echo ($q['cr_name']); ?></p>
           </div>
          </div>
          <?php //echo $q['id'];
          //echo get_prev_id($q['id'], $q['cr_level']);
          //  echo get_prev_lesson_code($q['id'], $q['cr_level']);
          //  echo test_score($_SESSION['std_id'], get_prev_lesson_code($q['id'], $q['cr_level']));
          ?>

          <div class="card-body">
           <figure>
            <h2><i class="fa fa-exclamation-circle"></i>
             test 1 Please go back and Retake Test for the previous topic.
             <a href="../study/<?php echo get_next_lesson(laster(get_last_lesson($_SESSION['std_id'])), $_SESSION['cr_lev']); ?>#<?php echo get_next_lesson(laster(get_last_lesson($_SESSION['std_id'])), $_SESSION['cr_lev']); ?>" class="btn-pill btn btn-warning btn-space text-left">Previous Lesson</a>
            </h2>
            <!-- <iframe src="../../schoolMaster/topics/Marriage Dynamics-FEPFL Marraige Acdemy.pdf" width="100%" height="500px" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen frameborder="0"></iframe> -->
           </figure>
          </div>
         </div>
         <?php //echo $q['id'];
         // echo get_prev_id($q['id'], $q['cr_level']);
         ?>
         <form action="">
          <div class="btn-list mt-4 ">

           <a href="../study/<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>#<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>" class="btn btn-secondary btn-space text-left">Previous Lesson</a>
          </div>
         </form>
        </div>
       <?php } elseif (cr_comp($_SESSION['std_id'], $_SESSION['cr_id']) < 1 && test_score($_SESSION['std_id'], get_prev_lesson_code($q['id'], $q['cr_level'])) < 5) { ?>
        <div class="col-md-12">
         <div class="card">
          <div class="card-header">
           <div class="card-title">
            <p class="text-danger">
             <?php //echo $q['cr_level'];
             // echo $pd['mode'];
             //echo student_type($pd['mode']);
             //  echo rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']));
             echo cert_type(rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']))); ?><i class="fe fe-chevron-right"></i> <?php echo '(' . $_SESSION['cr_id'] . ') ' . strtok($q['cr_name'], ':'); ?><i class="fe fe-chevron-right"></i> <?php echo ($q['cr_name']); ?></p>
           </div>
          </div>
          <?php //echo $q['id'];
          //echo get_prev_id($q['id'], $q['cr_level']);
          //  echo get_prev_lesson_code($q['id'], $q['cr_level']);
          //  echo test_score($_SESSION['std_id'], get_prev_lesson_code($q['id'], $q['cr_level']));
          ?>

          <div class="card-body">
           <figure>
            <h2><i class="fa fa-exclamation-circle"></i>
             test 2 Please go back and complete the previous topic. <?php // echo test_score($_SESSION['std_id'], first_course($_SESSION['cr_lev'])) 
                                                                    ?>
             <?php if (test_score($_SESSION['std_id'], first_course($_SESSION['cr_lev'])) > 0 && test_score($_SESSION['std_id'], first_course($_SESSION['cr_lev'])) < 5) { ?>
              <a href="../study/<?php echo get_first_lesson($_SESSION['cr_lev']); ?>#<?php echo get_first_lesson($_SESSION['cr_lev']); ?>" class="btn-pill btn btn-warning btn-space text-left">Previous Lesson</a>
             <?php } else { ?>
              <a href="../study/<?php echo get_next_lesson(laster(get_last_lesson($_SESSION['std_id'])), $_SESSION['cr_lev']); ?>#<?php echo get_next_lesson(laster(get_last_lesson($_SESSION['std_id'])), $_SESSION['cr_lev']); ?>" class="btn-pill btn btn-warning btn-space text-left">Previous Lesson</a>


             <?php  } ?>
            </h2>
            <!-- <iframe src="../../schoolMaster/topics/Marriage Dynamics-FEPFL Marraige Acdemy.pdf" width="100%" height="500px" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen frameborder="0"></iframe> -->
           </figure>
          </div>
         </div>
         <?php //echo $q['id'];
         // echo get_prev_id($q['id'], $q['cr_level']);
         ?>
         <form action="">
          <div class="btn-list mt-4 ">

           <a href="../study/<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>#<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>" class="btn btn-secondary btn-space text-left">Previous Lesson</a>
          </div>
         </form>
        </div>
       <?php } elseif (cr_comp($_SESSION['std_id'], $_SESSION['cr_id']) < 1) { ?>
        <div class="col-md-12">
         <div class="card">
          <div class="card-header">
           <div class="card-title">
            <p class="text-danger">
             <?php //echo $q['cr_level'];
             // echo $pd['mode'];
             //echo student_type($pd['mode']);
             //  echo rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']));
             echo cert_type(rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']))); ?><i class="fe fe-chevron-right"></i> <?php echo '(' . $q['cr_code'] . ') ' . strtok($q['cr_name'], ':'); ?><i class="fe fe-chevron-right"></i> <?php echo ($q['cr_name']); ?></p>
           </div>
          </div>
          <?php //echo $q['id'];
          //echo get_prev_id($q['id'], $q['cr_level']);
          // echo get_prev_lesson_code($q['id'], $q['cr_level']);
          //  echo test_score($_SESSION['std_id'], get_prev_lesson_code($q['id'], $q['cr_level']));
          ?>

          <div class="card-body">
           <figure>
            <iframe src="../../schoolMaster/topics/Marriage Dynamics-FEPFL Marraige Acdemy.pdf" width="100%" height="500px" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen frameborder="0"></iframe>
           </figure>
          </div>

         </div>
         <?php //echo $q['id'];
         // echo get_prev_id($q['id'], $q['cr_level']);
         ?>
         <form action="">
          <div class="btn-list mt-4 ">
           <?php if (get_prev_id($q['id'], $_SESSION['cr_lev']) == 0) {
           } else { ?>
            <a href="../study/<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>#<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>" class="btn btn-secondary btn-space text-left">Previous Lesson</a>
           <?php }  ?>
           <?php if (cr_comp($_SESSION['std_id'], $_SESSION['cr_id']) < 1) { ?>
            <!-- <a class=" ref btn btn-primary btn-space text-right text-white"><i class="fe fe-file"></i> Take Test </a> -->
            <a id="comp" data-id="<?php echo $_SESSION['cr_lev'] ?>" data-id2="<?php echo $_SESSION['cr_id']; ?>" class=" ref btn btn-primary btn-space text-right text-white"><i class="fe fe-check"></i> Mark Complete </a>
           <?php } else { ?>
            <a id="" class=" ref btn btn-primary btn-space text-right text-white text-muted ">Lesson Completed <i class="fe fe-check-circle"></i></a>
            <?php if (test_score($_SESSION['std_id'], $_SESSION['cr_id']) > 0 && test_score($_SESSION['std_id'], $_SESSION['cr_id']) < 5) { ?>
             <a id="" class=" btn btn-success btn-space text-right  text-white"><i class="fe fe-check"></i> Retake Test</a>
            <?php } elseif (empty(test_score($_SESSION['std_id'], $_SESSION['cr_id']))) { ?>
             <a id="" class=" btn btn-success btn-space text-right  text-white"><i class="fe fe-check"></i> Take Test</a>
            <?php } else { ?>
             <a id="" class=" ref btn btn-primary btn-space text-right text-white text-muted ">Test Completed <i class="fe fe-check-circle"></i></a>
             <a id="" class=" ref btn btn-primary btn-space text-right text-white text-muted ">View Score <i class="fe fe-check-circle"></i></a>
             <a href="../study/<?php echo get_next_lesson($q['id'], $_SESSION['cr_lev']); ?>#<?php echo get_next_lesson($q['id'], $_SESSION['cr_lev']); ?>" id="" class=" ref btn btn-info btn-space text-right text-white text-muted ">Next Lesson </a>

           <?php }
           } ?>
          </div>
         </form>
        </div>
       <?php } else { ?>
        <div class="col-md-12">
         <div class="card">
          <div class="card-header">
           <div class="card-title">
            <p class="text-danger">
             <?php //echo $q['cr_level'];
             // echo $pd['mode'];
             //echo student_type($pd['mode']);
             //  echo rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']));
             echo cert_type(rcr_lev($_SESSION['cr_lev'], student_type($pd['mode']))); ?><i class="fe fe-chevron-right"></i> <?php echo '(' . $q['cr_code'] . ') ' . strtok($q['cr_name'], ':'); ?><i class="fe fe-chevron-right"></i> <?php echo ($q['cr_name']); ?></p>
           </div>
          </div>
          <?php //echo $q['id'];
          //echo get_prev_id($q['id'], $q['cr_level']);
          // echo get_prev_lesson_code($q['id'], $q['cr_level']);
          //  echo test_score($_SESSION['std_id'], get_prev_lesson_code($q['id'], $q['cr_level']));
          ?>

          <div class="card-body">
           <figure>
            <iframe src="../../schoolMaster/topics/Marriage Dynamics-FEPFL Marraige Acdemy.pdf" width="100%" height="500px" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen frameborder="0"></iframe>
           </figure>
          </div>

         </div>
         <?php //echo $q['id'];
         // echo get_prev_id($q['id'], $q['cr_level']);
         ?>
         <form action="">
          <div class="btn-list mt-4 ">
           <?php if (get_prev_id($q['id'], $_SESSION['cr_lev']) == 0) {
           } else { ?>
            <a href="../study/<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>#<?php echo get_prev_lesson($q['id'], $_SESSION['cr_lev']); ?>" class="btn btn-secondary btn-space text-left">Previous Lesson</a>
           <?php }  ?>
           <?php if (cr_comp($_SESSION['std_id'], $_SESSION['cr_id']) < 1) { ?>
            <!-- <a class=" ref btn btn-primary btn-space text-right text-white"><i class="fe fe-file"></i> Take Test </a> -->
            <a id="comp" data-id="<?php echo $_SESSION['cr_lev'] ?>" data-id2="<?php echo $_SESSION['cr_id']; ?>" class=" ref btn btn-primary btn-space text-right text-white"><i class="fe fe-check"></i> Mark Complete </a>
           <?php } else { ?>
            <a id="" class=" ref btn btn-primary btn-space text-right text-white text-muted ">Lesson Completed <i class="fe fe-check-circle"></i></a>
            <?php if (test_score($_SESSION['std_id'], $_SESSION['cr_id']) > 0 && test_score($_SESSION['std_id'], $_SESSION['cr_id']) < 5) { ?>
             <a id="" class=" btn btn-success btn-space text-right  text-white"><i class="fe fe-check"></i> Retake Test</a>
            <?php } elseif (empty(test_score($_SESSION['std_id'], $_SESSION['cr_id']))) { ?>
             <a id="" class=" btn btn-success btn-space text-right  text-white"><i class="fe fe-check"></i> Take Test</a>
            <?php } else { ?>
             <a id="" class=" ref btn btn-primary btn-space text-right text-white text-muted ">Test Completed <i class="fe fe-check-circle"></i></a>

             <a id="" class=" ref btn btn-primary btn-space text-right text-white text-muted ">View Score <i class="fe fe-check-circle"></i></a>

             <a href="../study/<?php echo get_next_lesson($q['id'], $_SESSION['cr_lev']); ?>#<?php echo get_next_lesson($q['id'], $_SESSION['cr_lev']); ?>" id="" class=" ref btn btn-info btn-space text-right text-white text-muted ">Next Lesson </a>

           <?php }
           } ?>
          </div>
         </form>
        </div>
       <?php }
       ?>
      <?php } ?>
     </div>
    </div>
   </div>
  </div>

  <footer class="footer">
   <div class="container">
    <div class="row align-items-center ">
     <div class="col-12 col-lg-auto mt-3 mt-lg-0">
      <p class="text-center">Copyright &copy; <?php echo date('Y'); ?> <a href="https://familypeace247.org">FEPFL Marriage Academy</a></p>
     </div>
    </div>
   </div>
  </footer>
 </div>

 <?php include('scripts.php'); ?>
 <?php include('modals.php'); ?>
 <script>
  $(document).ready(function() {

   $('#comp').on('click', function() {
    var f_id = $(this).data('id');
    var f_id2 = $(this).data('id2');
    $post = $(this);
    //alert(f_id);
    $.ajax({
     url: 'course',
     type: 'post',
     data: {
      'comp': 1,
      'cr_lev': f_id,
      'cr_id': f_id2
     },
     success: function(response) {
      //alert(f_id);
      //$post.parent().find('p.follo').text(response);
      $post.parent().find('a.ref').text(' Completed');
      $post.addClass('hide');
      $post.siblings().removeClass('hide');
      location.reload();
     }
    });
   });
  });
 </script>
</body>

</html>