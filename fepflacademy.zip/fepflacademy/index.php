<?php ob_start();
session_start();
require('db/config.php');
require('db/functions.php');
if (isset($_SESSION['std_email'])) {
  $std = get_stud_details($_SESSION['std_email']);
  extract($std);


  //error_reporting(0);
} else {
  header("location:login");
}
$link = 1;
?>
<!doctype html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta http-equiv="Content-Language" content="en" />
  <meta name="msapplication-TileColor" content="#2d89ef">
  <meta name="theme-color" content="#4188c9">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="HandheldFriendly" content="True">
  <meta name="MobileOptimized" content="320">
  <!-- Generated: 2018-04-06 16:27:42 +0200 -->
  <title>Homepage - FEPFL Marriage Academy</title>
  <?php include('link.php'); ?>
</head>

<body class="">
  <div class="page">
    <div class="page-main">
      <?php include('header.php'); ?>

      <?php
      //if the user tried to pay but it was unsuccessful
      if (try_pay($_SESSION['std_email']) > 0 &&  pay_stat($_SESSION['std_email']) < 1) {
        $pd = get_pay_detail($_SESSION['std_email']);
        extract($pd); ?>
        <div class="my-3 my-md-5">
          <div class="container">
            <div class="row page-header">
              <div class="col-md-12">
                <h1 class="text-center" style="text-align:center">
                  Welcome, <?php echo $std['std_fname']; ?> to FEPFL Marriage Academy </h1>
              </div>

            </div>


            <div class="row  align-items-center text-center">

              <div class="col-md-12">
                <h3>Your Previous attempt to pay for the form was unsuccessful, you can try again or try another payment channel below.</h3>
                <h4>Your Payment Details are as Follows: <br>Certificate Type: <b style="color:red"><?php echo cert_type($pd['mode']); ?></b> &nbsp;&nbsp; Study Mode: <b style="color:red"><?php echo get_study_mode($pd['mode']); ?></b> &nbsp;&nbsp; Student Type: <b style="color:red"><?php echo student_type($pd['mode']); ?> &nbsp; &nbsp;</b> Amount: <b style="color:red"><?php echo $pd['price']; ?></b></h4>
                <p>If you have made payments through the Bank or via transfer, <a href="#" class="btn btn-danger"> Click Here</a> to enter your payment ID</p>
              </div>

              <div class="row">
                <div class=" col-md-6">
                  <div class="card ">
                    <div class="card-body ">
                      <a href="verify.php?pay_id=<?php echo $pd['pay_id']; ?>&ref=<?php echo $pd['pay_ref']; ?>&mode=<?php echo $pd['mode']; ?>&price=<?php echo $pd['price']; ?>" style="text-decoration: none;">
                        <div class="card-body">
                          <div class="media">
                            <span class="avatar avatar-xxl mr-5" style=""><i class="fa fa-credit-card"></i></span>
                            <div class="media-body">
                              <h2 class="m-0">Retry PayStack</h2>
                              <p class="text-dark mb-0">Complete your payments using the paystack platform with your Master or VISA ATM Charge.</p>
                            </div>
                          </div>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>

                <div class=" col-md-6">
                  <div class="card ">
                    <div class="card-body ">
                      <a href="#" style="text-decoration: none;">
                        <div class="card-body">
                          <div class="media">
                            <span class="avatar avatar-xxl mr-5" style=""><i class="fa fa-credit-card"></i></span>
                            <div class="media-body">
                              <h2 class="m-0">Bank Transfer/Deposit</h2>
                              <p class="text-dark mb-0">Complete your payments by paying into the FEPFL Marriage Academy bank.<br><b>Account Name: FEPFL Marriage Academy <br>Account Number: 1024653058 (UBA Bank)<br></b> You transaction will be processed within 24hours.</p>
                            </div>
                          </div>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      <?php  }  ?>

      <?php //if the user just login and no payments has been made or attempted the 
      if (try_pay($_SESSION['std_email']) < 1 &&  pay_stat($_SESSION['std_email']) < 1) { ?>
        <div class="my-3 my-md-5">
          <div class="container">
            <div class="row page-header">
              <div class="col-md-12">
                <h1 class="text-center" style="text-align:center">
                  Welcome, <?php echo $std['std_fname']; ?> You are applying for the FEPFL Marriage Academy </h1>
              </div>
            </div>


            <div class="row  align-items-center text-center">
              <div class="col-md-12">
                <h3>To proceed to the form payment, kindly select your Study mode below.</h3>
                <p>To learn more about the learning modes kindly check out the FEPFL Marraiage Academy<a href="learning_mode"> Learning Mode</a></p>
              </div>

              <div class="col-md-6">
                <div class="card">
                  <div class="card-body">
                    <h1>Full-Time Study</h1>
                    <a href="#" data-toggle="modal" data-target="#payment1" class="btn btn-primary text-center">Single Payments </a>
                    <a href="#" data-toggle="modal" data-target="#payment2" class="btn btn-primary text-center">Couple Payments </a>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="card">
                  <div class="card-body">
                    <h1>Batch Study</h1>
                    <a href="#" data-toggle="modal" data-target="#payment3" class="btn btn-primary text-center">Single Payments </a>
                    <a href="#" data-toggle="modal" data-target="#payment4" class="btn btn-primary text-center">Couple Payments </a>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      <?php } ?>
      <?php //if the users has completed payments but not filled the form
      if (try_pay($_SESSION['std_email']) > 0 && pay_stat($_SESSION['std_email']) > 0 && form_fill($_SESSION['std_email']) < 1) {
        $pd = get_pay_detail($_SESSION['std_email']);
        extract($pd); ?>

        <div class="my-3 my-md-5">
          <div class="container">
            <div class="row page-header">
              <div class="col-md-12">
                <h1 class="text-center" style="text-align:center">
                  Welcome, <?php echo $std['std_fname']; ?> to FEPFL Marriage Academy
                </h1>
                <h3 class="text-center" style="text-align:center">Kindly Complete Your Forms to Complete Registration</h3>
              </div>
              <div class="col-md-12 text-center">
                <h4 style="text-align: center;">Application Details <br>: <br>Certificate Type: <b style="color:red"><?php echo $_SESSION['cert_type'] =  cert_type($pd['mode']); ?></b> &nbsp;&nbsp; Study Mode: <b style="color:red"><?php echo $_SESSION['study_mode'] = get_study_mode($pd['mode']); ?></b> &nbsp;&nbsp; Student Type: <b style="color:red"><?php echo $_SESSION['student_type'] = student_type($pd['mode']); ?> &nbsp; &nbsp;</b></h4>
              </div>

              <div class="col-md-12">
                <?php if (($pd['mode']) == 'LEV1S' || ($pd['mode']) == 'FULLS') { ?>
                  <form class="card" action="" method="POST" enctype="multipart/form-data">

                    <?php if (isset($_POST['updlvs'])) {
                      $_SESSION['cert_type'];
                      $_SESSION['study_mode'];
                      $_SESSION['student_type'];

                      $email = $_SESSION['std_email'];
                      $title = $_POST['title'];
                      $oname = $_POST['oname'];
                      $gender = $_POST['gender'];
                      $age = $_POST['age'];
                      $phone = $_POST['phone'];
                      $country = $_POST['country'];
                      $state = $_POST['state'];
                      $lga = $_POST['lga'];
                      $postal = $_POST['postal'];
                      $religion = $_POST['religion'];
                      $qual = $_POST['qual'];
                      $job = $_POST['job'];
                      $desg = $_POST['desg'];
                      $plac = $_POST['plac'];
                      $std_id = get_last_num();
                      if (QueryDB("SELECT COUNT(*) FROM rstudents where std_email='$email' ")->fetchColumn() > 0) {
                        print "<script>swal({text:'Form Filled',type:'sucess', title:'Completed'}, function(){ window.location = 'index'});</script>";
                      }
                      if (QueryDB("INSERT INTO rstudents (std_id, std_level, std_country, std_state, std_lga, std_addr, std_religion, std_email, std_qual, std_job, std_jobp, std_desg, std_iden, std_m, std_mstat, std_myrs, std_noc, std_mtype, std_mdate, std_mcode, std_mdoc, std_passport, reg_date, status
) VALUES('$std_id','" . $pd['mode'] . "','$country','$state','$lga','$postal','$religion','$email','$qual','$job','$plac','$desg','','','',0,0,0,'','','','','" . time() . "',0) ") && QueryDB("UPDATE students SET std_oname='$oname', std_title='$title', std_sex='$gender', std_age='$age', std_phone='$phone' where std_email='$email' ")) {
                        print "<script>swal({text:'Form Filled',type:'sucess', title:'Completed'}, function(){ window.location = 'index'});</script>";
                      } else {
                        print "<script>swal({text:'Not suceessful',type:'danger', title:'Error Occured'}, function(){ window.location = 'index'});</script>";
                      }
                    }




                    ?>
                    <div class="card-body">
                      <h3 class="card-title" style="font-weight:bold;">Personal Information</h3>
                      <div class="row">
                        <div class="col-md-3">
                          <div class="form-group">
                            <label class="form-label">Title <span class="form-required">*</span></label>
                            <select name="title" class="form-control custom-select">
                              <option value="">Choose title</option>
                              <option value="Mr">Mr.</option>
                              <option value="Mrs">Mrs.</option>
                              <option value="Miss">Miss</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                          <div class="form-group">
                            <label class="form-label">First Name <span class="form-required">*</span></label>
                            <input type="text" name="" readonly class="form-control" placeholder="First Name" value="<?php echo $std['std_fname']; ?>">
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                          <div class="form-group">
                            <label class="form-label">Other Name</label>
                            <input type="text" name="oname" class="form-control" placeholder="Other Name" value="<?php echo $std['std_oname']; ?>">
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                          <div class="form-group">
                            <label class="form-label">Last Name <span class="form-required">*</span></label>
                            <input type="text" name="" readonly class="form-control" placeholder="Last name" value="<?php echo $std['std_lname']; ?>">
                          </div>
                        </div>
                        <div class="col-md-3">
                          <div class="form-group">
                            <label class="form-label">Gender <span class="form-required">*</span></label>
                            <select name="gender" class="form-control custom-select" required>
                              <option value="">Choose Gender</option>
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                              <option value="Custom">Custom</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-3">
                          <div class="form-group">
                            <label class="form-label">Age <span class="form-required">*</span></label>
                            <select name="age" class="form-control custom-select" required>
                              <option value="">Choose Age Grade</option>
                              <option value="18-25">18-25</option>
                              <option value="26-35">26-35</option>
                              <option value="36-40">36-40</option>
                              <option value="41-50">41-45</option>
                              <option value="46-50">46-50</option>
                              <option value="51-60">51-60</option>
                              <option value="Older">Older</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-3">
                          <div class="form-group">
                            <label class="form-label">Religion <span class="form-required">*</span></label>
                            <select name="religion" class="form-control custom-select" required>
                              <option value="">Choose Religion</option>
                              <option value="Christianity">Christianity</option>
                              <option value="Islam">Islam</option>
                              <option value="Others">Others</option>
                            </select>
                          </div>
                        </div>
                      </div>

                      <h3 class="card-title" style="font-weight:bold;">Contact Information</h3>
                      <div class="row">
                        <div class="col-sm-3 col-md-3">
                          <div class="form-group">
                            <label class="form-label">Phone <span class="form-required">*</span></label>
                            <input type="text" name="phone" class="form-control" required placeholder="e.g +2349012345678">
                          </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                          <label for="country" class="form-label">Country <span class="form-required">*</span></label>
                          <select class="form-control custom-select" name="country" id="country" required="">
                            <option value="">[Choose Country]</option> <?php foreach (QueryDB("SELECT * FROM countries WHERE status = 0  ") as $ct) { ?>
                              <option value="<?php echo $ct['name']; ?>" id="<?php echo $ct['id']; ?>"><?php echo $ct['name']; ?></option> <?php  } ?>
                          </select>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                          <label class="control-label" for="lastname">State <span class="form-required">*</span></label>
                          <select class="form-control " name="state" id="state" required="">
                            <option value="">[Choose State]</option>
                          </select>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12" id="lga2">
                          <label class="control-label" id="" for="lastname">LGA <span class="form-required">*</span></label>
                          <select class="form-control " name="lga" id="lga" required="">
                            <option value="">[Choose LGA]</option>
                          </select>
                        </div>
                        <div class="col-sm-6 col-md-3">
                          <div class="form-group">
                            <label class="form-label">Postal Code</label>
                            <input type="number" name="postal" class="form-control" placeholder="ZIP Code">
                          </div>
                        </div>
                      </div>
                      <h3 class="card-title" style="font-weight:bold;">Qualification and Job Information</h3>

                      <div class="row">
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Highest Qualification <span class="form-required">*</span></label>
                            <select class="form-control custom-select" required name="qual">
                              <option value="">[Choose Qualification type]</option>
                              <option value="HS">High School</option>
                              <option value="GS">Grad School</option>
                              <option value="ND">National Diploma </option>
                              <option value="HND">Higher National Diploma </option>
                              <option value="BSC">Bachelor's Degree</option>
                              <option value="MSC">Maters's Degree</option>
                              <option value="PHD">PHD</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Type of Job<span class="form-required">*</span></label>
                            <input type="text" name="job" class="form-control" placeholder="Type of Job" value="">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Designation<span class="form-required">*</span></label>
                            <input type="text" name="desg" class="form-control" placeholder="Designation" value="">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Place of Work<span class="form-required">*</span></label>
                            <input type="text" name="plac" class="form-control" placeholder="Place of Work" value="">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-12 col-sm-12 col-12 mb-2">
                        <label class="custom-control custom-checkbox">
                          <input class="custom-control-input" type="checkbox" required=""><span class="custom-control-label">By creating an account, you agree that Your
                            email and personal details will be used for official correspondence from <a href="https://familypeace247.org/academy">FEPFL Marriage Academy</a>
                            and password recovery. You may update this information later if any changes are made. See our <a href="#" target="_blank" class="required"> Privacy Policy</a> for more
                            information about the use of collected information. </span>
                        </label>
                      </div>
                      <div class="card-footer text-right">
                        <input type="submit" name="updlvs" class="btn btn-primary" value="Submit Info">
                      </div>
                    </div>
                  </form>
                <?php    } ?>

                <?php if (($pd['mode']) == 'LEV1C' || ($pd['mode']) == 'FULLC') { ?>
                  <form class="card" action="" method="POST" enctype="multipart/form-data">
                    <div class="card-body">
                      <h3 class="card-title" style="font-weight:bold;">Personal Information</h3>
                      <!-- <h3 class="card-title" style="font-weight:bold;">Personal Information</h3> -->
                      <div class="row">
                        <div class="col-md-3">
                          <div class="form-group">
                            <label class="form-label">Title <span class="form-required">*</span></label>
                            <select name="title" class="form-control custom-select">
                              <option value="">Choose title</option>
                              <option value="Mr">Mr.</option>
                              <option value="Mrs">Mrs.</option>
                              <option value="Miss">Miss</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                          <div class="form-group">
                            <label class="form-label">First Name <span class="form-required">*</span></label>
                            <input type="text" name="" readonly class="form-control" placeholder="First Name" value="<?php echo $std['std_fname']; ?>">
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                          <div class="form-group">
                            <label class="form-label">Other Name</label>
                            <input type="text" name="oname" class="form-control" placeholder="Other Name" value="<?php echo $std['std_oname']; ?>">
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                          <div class="form-group">
                            <label class="form-label">Last Name <span class="form-required">*</span></label>
                            <input type="text" name="" readonly class="form-control" placeholder="Last name" value="<?php echo $std['std_lname']; ?>">
                          </div>
                        </div>
                        <div class="col-md-3">
                          <div class="form-group">
                            <label class="form-label">Gender <span class="form-required">*</span></label>
                            <select name="gender" class="form-control custom-select" required>
                              <option value="">Choose Gender</option>
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                              <option value="Custom">Custom</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-3">
                          <div class="form-group">
                            <label class="form-label">Age <span class="form-required">*</span></label>
                            <select name="age" class="form-control custom-select" required>
                              <option value="">Choose Age Grade</option>
                              <option value="18-25">18-25</option>
                              <option value="26-35">26-35</option>
                              <option value="36-40">36-40</option>
                              <option value="41-50">41-45</option>
                              <option value="46-50">46-50</option>
                              <option value="51-60">51-60</option>
                              <option value="Older">Older</option>
                            </select>
                          </div>
                        </div>
                      </div>

                      <h3 class="card-title" style="font-weight:bold;">Contact Information</h3>
                      <div class="row">
                        <div class="col-sm-3 col-md-3">
                          <div class="form-group">
                            <label class="form-label">Phone <span class="form-required">*</span></label>
                            <input type="text" name="phone" class="form-control" required placeholder="e.g +2349012345678">
                          </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                          <label for="country" class="form-label">Country <span class="form-required">*</span></label>
                          <select class="form-control custom-select" name="country" id="country" required="">
                            <option value="">[Choose Country]</option> <?php foreach (QueryDB("SELECT * FROM countries WHERE status = 0  ") as $ct) { ?>
                              <option value="<?php echo $ct['name']; ?>" id="<?php echo $ct['id']; ?>"><?php echo $ct['name']; ?></option> <?php  } ?>
                          </select>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                          <label class="control-label" for="lastname">State <span class="form-required">*</span></label>
                          <select class="form-control " name="state" id="state" required="">
                            <option value="">[Choose State]</option>
                          </select>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12" id="lga2">
                          <label class="control-label" id="" for="lastname">LGA <span class="form-required">*</span></label>
                          <select class="form-control " name="lga" id="lga" required="">
                            <option value="">[Choose LGA]</option>
                          </select>
                        </div>
                        <div class="col-sm-6 col-md-3">
                          <div class="form-group">
                            <label class="form-label">Postal Code</label>
                            <input type="number" name="postal" class="form-control" placeholder="ZIP Code">
                          </div>
                        </div>
                      </div>
                      <h3 class="card-title" style="font-weight:bold;">Qualification and Job Information</h3>

                      <div class="row">
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Highest Qualification <span class="form-required">*</span></label>
                            <select class="form-control custom-select" required name="qual">
                              <option value="">[Choose Qualification type]</option>
                              <option value="HS">High School</option>
                              <option value="GS">Grad School</option>
                              <option value="ND">National Diploma </option>
                              <option value="HND">Higher National Diploma </option>
                              <option value="BSC">Bachelor's Degree</option>
                              <option value="MSC">Maters's Degree</option>
                              <option value="PHD">PHD</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Type of Job<span class="form-required">*</span></label>
                            <input type="text" name="job" class="form-control" placeholder="Type of Job" value="<?php echo $std['std_job']; ?>">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Designation<span class="form-required">*</span></label>
                            <input type="text" name="desg" class="form-control" placeholder="Designation" value="<?php echo $std['std_desg']; ?>">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Place of Work<span class="form-required">*</span></label>
                            <input type="text" name="plac" class="form-control" placeholder="Place of Work" value="<?php echo $std['std_jobp']; ?>">
                          </div>
                        </div>
                      </div>
                      <h3 class="card-title" style="font-weight:bold;">Marital Information</h3>
                      <div class="row">
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Marital Status <span class="form-required">*</span></label>
                            <select class="form-control custom-select" required name="marital">
                              <option value="">[Choose Marital Status]</option>
                              <option value="MAR">Married</option>
                              <option value="ATW">About to Wed</option>
                              <option value="SEP">Seperated </option>
                              <option value="SIN">Single Parent</option>

                            </select>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Marriage Type<span class="form-required">*</span></label>
                            <select class="form-control custom-select" required name="martype">
                              <option value="">[Choose Marriage Type]</option>
                              <option value="TRAD">Traditional</option>
                              <option value="REG">Registry</option>
                              <option value="CHU">Church </option>
                              <option value="ISL">Islamic</option>

                            </select>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Years in Marriage<span class="form-required">*</span></label>
                            <input type="number" name="yom" class="form-control" value="">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Date of Marriage<span class="form-required">*</span></label>
                            <input type="date" name="dom" class="form-control" value="">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">No. of Children <i>(If any)</i><span class="form-required">*</span></label>
                            <input type="number" name="child" class="form-control" value="">
                          </div>
                        </div>
                      </div>
                      <h3 class="card-title" style="font-weight:bold;">Marital Document</h3>
                      <div class="row">
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Couples Code<span class="form-required">*</span></label>
                            <input type="text" name="ccode" class="form-control" value="">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Marriage Certificate<span class="form-required">*</span></label>
                            <input type="file" name="mcert" class="form-control" value="">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-12 col-sm-12 col-12 mb-2">
                        <label class="custom-control custom-checkbox">
                          <input class="custom-control-input" type="checkbox" required=""><span class="custom-control-label">By creating an account, you agree that Your
                            email and personal details will be used for official correspondence from <a href="https://familypeace247.org/academy">FEPFL Marriage Academy</a> and password recovery. You may update this information later if any
                            changes are made. See our <a href="#" target="_blank" class="required"> Privacy Policy</a> for more
                            information about the use of collected information. </span>
                        </label>
                      </div>
                      <div class="card-footer text-right">
                        <input type="submit" name="updlvc" class="btn btn-primary" value="Submit Info">
                      </div>
                    </div>
                  </form>
                <?php  } ?>

                <?php if (($pd['mode']) == 'LEV2S' || ($pd['mode']) == 'LEV2C') { ?>
                  <form class="card" action="" method="POST" enctype="multipart/form-data">
                    <div class="card-body">

                      <h3 class="card-title" style="font-weight:bold;">Proof of Level 1 Completion</h3>
                      <div class="row">
                        <div class="col-md-4">
                          <div class="form-group">
                            <label class="form-label">Certificate Code<span class="form-required">*</span></label>
                            <input type="text" name="certcode" class="form-control" required value="">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-12 col-sm-12 col-12 mb-2">
                        <label class="custom-control custom-checkbox">
                          <input class="custom-control-input" type="checkbox" required=""><span class="custom-control-label">By creating an account, you agree that Your
                            email and personal details will be used for official correspondence from <a href="https://familypeace247.org/academy">FEPFL Marriage Academy</a> and password recovery. You may update this information later if any
                            changes are made. See our <a href="#" target="_blank" class="required"> Privacy Policy</a> for more
                            information about the use of collected information. </span>
                        </label>
                      </div>
                      <div class="card-footer text-right">
                        <input type="submit" name="updcert" class="btn btn-primary" value="Submit Info">
                      </div>
                    </div>
                  </form>
                <?php  } ?>
              </div>

            </div>
          </div>
        </div>
      <?php  } ?>
      <div class="my-3 my-md-5">
        <div class="container">
          <?php //if the user has completed form payments and filled the form
          if (try_pay($_SESSION['std_email']) > 0 && pay_stat($_SESSION['std_email']) > 0 && form_fill($_SESSION['std_email']) > 0) {
            $pd = get_pay_detail($_SESSION['std_email']);
            extract($pd); ?>


            <div class="row page-header">
              <div class="col-md-12">
                <h1 class="text-center" style="text-align:center">
                  Welcome, <?php echo $std['std_fname']; ?> to FEPFL Marriage Academy
                </h1>
                <div class="col-md-12 text-center">
                  <h4 style="text-align: center;">Application Details <br><br>Certificate Type: <b style="color:red"><?php echo  ; ?></b> &nbsp;&nbsp; Study Mode: <b style="color:red"><?php echo get_study_mode($pd['mode']); ?></b> &nbsp;&nbsp; Student Type: <b style="color:red"><?php echo student_type($pd['mode']); ?> &nbsp; &nbsp;</b></h4>
                </div>
                <h3>Your Courses </h3>

                <div class="row">
                  <?php //echo $crl = ($pd['mode']);
                  foreach (QueryDB("SELECT * FROM rstudents where std_email='" . $_SESSION['std_email'] . "' ") as $row) {
                    extract($row); ?>
                    <div class="col-md-12 col-xl-12">
                      <div class="card card-collapsed">
                        <div class="card-header">
                          <div class="card-status card-status-left bg-blue"></div>
                          <h3 class="card-title"><a href="#"><b style="color:blue"><?php echo cert_type($std_level); ?> Courses</b></a></h3>
                          <div class="card-options">
                            <a class="btn btn-pill btn-primary btn-sm text-white">In Progress</a>
                            <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-circle-down"></i></a>
                            <!-- <a href="#" class="card-options-remove" data-toggle="card-remove"><i class="fe fe-x"></i></a> -->
                          </div>
                        </div>

                        <ul class="list-group card-list-group">
                          <?php //echo $std_level;
                          $crcl = cr_lev($std_level);
                          //  echo ("SELECT * FROM courses where cr_level='$crcl' ");
                          foreach (QueryDB("SELECT * FROM courses where cr_level='$crcl' ") as $crc) {
                            extract($crc); ?>
                            <li class="list-group-item list-group-item-red">
                              <a href="study/<?php echo $cr_link; ?>#<?php echo $cr_link; ?>" class="text-inherit"><?php if ($crcl == $cr_level) {
                                                                                                                      echo $cr_code . ' - ' . $cr_name;
                                                                                                                    }

                                                                                                                    ?>
                                <?php if (cr_comp($std_id, $cr_code) < 1) { ?>
                                  <span class="float-right text-white btn btn-pill btn-primary btn-sm">Continue</span><?php } else { ?>
                                  <span class="float-right text-white btn btn-pill btn-success btn-sm">Finished</span>
                                <?php } ?>
                              </a>
                            </li>
                          <?php } ?>
                        </ul>

                      </div>
                    </div>
                  <?php } ?>

                  <!-- <div class="col-3">
                    <div class="card">
                      <div class="card-status bg-green"></div>
                      <div class="card-body text-center">
                        <div class="card-category">Premium</div>
                        <div class="display-3 my-4">$49</div>
                        <ul class="list-unstyled leading-loose">
                          <li><strong>10</strong> Users</li>
                          <li><i class="fe fe-check text-success mr-2" aria-hidden="true"></i> Sharing Tools</li>
                          <li><i class="fe fe-check text-success mr-2" aria-hidden="true"></i> Design Tools</li>
                          <li><i class="fe fe-x text-danger mr-2" aria-hidden="true"></i> Private Messages</li>
                          <li><i class="fe fe-x text-danger mr-2" aria-hidden="true"></i> Twitter API</li>
                        </ul>
                        <div class="text-center mt-6">
                          <a href="#" class="btn btn-green btn-block">Choose plan</a>
                        </div>
                      </div>
                    </div>
                  </div> -->
                </div>
              </div>

            </div>

          <?php  } ?>
        </div>
      </div>

      <footer class="footer">
        <div class="container">
          <div class="row align-items-center ">
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
              <p class="text-center">Copyright &copy; <?php echo date('Y'); ?> <a href="https://familypeace247.org">FEPFL Marriage Academy</a></p>
            </div>
          </div>
        </div>
      </footer>
    </div>

    <?php include('scripts.php'); ?>
    <?php include('modals.php'); ?>

</body>

</html>